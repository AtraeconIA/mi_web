import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Music2, Instagram, Youtube } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export default function Footer() {
  const [showAdminPopup, setShowAdminPopup] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);

  const handleAdminAccess = () => {
    if (password === 'ReyesVizcaino') {
      window.location.href = createPageUrl('Admin');
    } else {
      setError(true);
      setTimeout(() => setError(false), 2000);
      setPassword('');
    }
  };

  return (
    <footer className="bg-black border-t border-white/10">
      <div className="container mx-auto px-4 py-10 md:py-12">
        {/* Social Icons */}
        <div className="flex justify-center gap-4 mb-6">
          <a
            href="https://open.spotify.com/intl-es/artist/7a9ocgPbS1GWJ4hfg0SINH"
            target="_blank"
            rel="noopener noreferrer"
            className="text-white/40 hover:text-[#1DB954] transition-colors"
            aria-label="Spotify"
          >
            <Music2 className="w-5 h-5" />
          </a>
          <a
            href="https://instagram.com/vizcainoreyes"
            target="_blank"
            rel="noopener noreferrer"
            className="text-white/40 hover:text-pink-400 transition-colors"
            aria-label="Instagram"
          >
            <Instagram className="w-5 h-5" />
          </a>
          <a
            href="https://youtube.com/@vizcainoreyes"
            target="_blank"
            rel="noopener noreferrer"
            className="text-white/40 hover:text-red-500 transition-colors"
            aria-label="YouTube"
          >
            <Youtube className="w-5 h-5" />
          </a>
        </div>

        {/* Legal Links - Like the reference image */}
        <div className="flex flex-wrap justify-center gap-4 md:gap-8 text-white/40 text-xs md:text-sm mb-8">
          <Link to={createPageUrl('PrivacyPolicy')} className="hover:text-white transition-colors">
            Política de Privacidad
          </Link>
          <Link to={createPageUrl('LegalNotice')} className="hover:text-white transition-colors">
            Aviso Legal
          </Link>
          <Link to={createPageUrl('CookiesPolicy')} className="hover:text-white transition-colors">
            Política de Cookies
          </Link>
          <Link to={createPageUrl('TermsOfUse')} className="hover:text-white transition-colors">
            Términos de Uso
          </Link>
        </div>

        {/* Copyright */}
        <p className="text-white/20 text-xs text-center">
          © 2026 Vizcaíno Reyes. Todos los derechos reservados.
        </p>
      </div>
      
      {/* Admin Access Button - Bottom Left Fixed */}
      <button
        onClick={() => setShowAdminPopup(true)}
        className="fixed bottom-6 left-6 w-10 h-10 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center transition-all z-40"
        title="Admin"
      >
        <div className="w-1.5 h-1.5 rounded-full bg-white/30" />
      </button>
      
      {/* Admin Password Popup */}
      {showAdminPopup && (
        <div 
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50"
          onClick={() => setShowAdminPopup(false)}
        >
          <div 
            className="bg-neutral-900 border border-white/10 rounded-xl p-6 w-80 max-w-[90%]"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-white font-heading text-xl mb-4">Acceso Admin</h3>
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAdminAccess()}
              placeholder="Contraseña"
              className={`w-full bg-white/5 border ${error ? 'border-red-500' : 'border-white/20'} text-white px-4 py-2 rounded-lg mb-4`}
              autoFocus
            />
            {error && <p className="text-red-500 text-xs mb-3">Contraseña incorrecta</p>}
            <div className="flex gap-2">
              <Button
                onClick={() => setShowAdminPopup(false)}
                className="flex-1 bg-white/5 hover:bg-white/10 text-white"
              >
                Cancelar
              </Button>
              <Button
                onClick={handleAdminAccess}
                className="flex-1 bg-[#8B1538] hover:bg-[#6A1029] text-white"
              >
                Entrar
              </Button>
            </div>
          </div>
        </div>
      )}
    </footer>
  );
}
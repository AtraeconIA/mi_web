import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Music2 } from 'lucide-react';
import { useScrollPosition } from '../hooks/useScrollPosition';
import { cn } from '@/lib/utils';
import ContactPopup from '../contact/ContactPopup';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const { isAtTop } = useScrollPosition();

  const navItems = [
    { key: 'about', label: 'Sobre Mí', href: '#about' },
    { key: 'gallery', label: 'Galería', href: '#gallery' },
    { key: 'shop', label: 'Consigue tu Disco', href: '#shop' },
    { key: 'contact', label: 'Contacto', href: null, action: 'contact' },
  ];

  const scrollToSection = (href) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  const handleNavClick = (item) => {
    if (item.action === 'contact') {
      setIsContactOpen(true);
      setIsMenuOpen(false);
    } else if (item.href) {
      scrollToSection(item.href);
    }
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 px-3 md:px-4 pt-3">
        <div
          className={cn(
            'mx-auto max-w-5xl transition-all duration-500 rounded-xl',
            'bg-black/70 backdrop-blur-xl border border-white/10',
            'px-4 md:px-5 py-2'
          )}
        >
          <div className="flex items-center justify-between">
            {/* Logo */}
            <button 
              onClick={() => scrollToSection('#hero')}
              className="font-heading text-lg md:text-xl text-white tracking-wider hover:opacity-80 transition-opacity"
            >
              VIZCAÍNO REYES
            </button>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-6">
              {navItems.map((item) => (
                <button
                  key={item.key}
                  onClick={() => handleNavClick(item)}
                  className="text-white/60 hover:text-white transition-colors text-xs uppercase tracking-widest font-medium"
                >
                  {item.label}
                </button>
              ))}
            </nav>

            {/* Spotify Icon */}
            <div className="flex items-center gap-3">
              <a
                href="https://open.spotify.com/intl-es/artist/7a9ocgPbS1GWJ4hfg0SINH"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#1DB954] hover:scale-110 transition-transform"
                aria-label="Spotify"
              >
                <Music2 className="w-4 h-4 md:w-5 md:h-5" />
              </a>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="lg:hidden text-white p-1"
                aria-label="Toggle menu"
              >
                {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-black/98 backdrop-blur-lg lg:hidden pt-20"
          >
            <nav className="flex flex-col items-center justify-center h-full gap-8">
              {navItems.map((item, index) => (
                <motion.button
                  key={item.key}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  onClick={() => handleNavClick(item)}
                  className="text-white text-2xl uppercase tracking-widest font-medium hover:text-white/70 transition-colors"
                >
                  {item.label}
                </motion.button>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Contact Popup - Lazy loaded on click */}
      <ContactPopup isOpen={isContactOpen} onClose={() => setIsContactOpen(false)} />
    </>
  );
}
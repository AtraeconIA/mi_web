import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Mail, Phone, User, MessageSquare, CheckCircle, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { base44 } from '@/api/base44Client';

export default function ContactPopup({ isOpen, onClose }) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'booking',
    message: '',
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    await base44.entities.ContactMessage.create({
      ...formData,
      status: 'pending',
    });
    setIsSuccess(true);
    setFormData({ name: '', email: '', phone: '', subject: 'booking', message: '' });
    setIsSubmitting(false);
  };

  const handleClose = () => {
    onClose();
    setTimeout(() => setIsSuccess(false), 300);
  };

  const whatsappMessage = encodeURIComponent("¡Hola! Me gustaría ponerme en contacto contigo.");
  const whatsappUrl = `https://wa.me/34635571408?text=${whatsappMessage}`;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          onClick={handleClose}
        >
          {/* Backdrop */}
          <div className="absolute inset-0 bg-black/90 backdrop-blur-xl" />
          
          {/* Modal */}
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={{ type: "spring", damping: 25 }}
            className="relative w-full max-w-lg z-10"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              onClick={handleClose}
              className="absolute -top-12 right-0 text-white/70 hover:text-white transition-colors p-2"
            >
              <X className="w-7 h-7" />
            </button>

            {/* Form Card */}
            <div className="bg-[#0d0d0d]/95 backdrop-blur-xl rounded-2xl p-6 md:p-8 border border-white/10 shadow-2xl">
              {/* Header */}
              <div className="text-center mb-6">
                <h3 className="font-heading text-2xl md:text-3xl text-white">Contacto</h3>
                <p className="text-white/50 text-sm mt-1">Contrataciones y colaboraciones</p>
              </div>

              {isSuccess ? (
                <div className="text-center py-6">
                  <CheckCircle className="w-14 h-14 text-green-500 mx-auto mb-4" />
                  <h4 className="font-heading text-xl text-white mb-2">¡Mensaje Enviado!</h4>
                  <p className="text-white/60 mb-6 text-sm">Te responderé lo antes posible.</p>
                  <Button
                    className="bg-white/10 hover:bg-white/20 rounded-xl"
                    onClick={() => setIsSuccess(false)}
                  >
                    Enviar otro mensaje
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Row 1: Name & Phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                      <Input
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        required
                        className="bg-white/5 border-white/10 text-white pl-10 h-11 rounded-xl text-sm placeholder:text-white/30"
                        placeholder="Nombre"
                      />
                    </div>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                      <Input
                        value={formData.phone}
                        onChange={(e) => setFormData({...formData, phone: e.target.value})}
                        className="bg-white/5 border-white/10 text-white pl-10 h-11 rounded-xl text-sm placeholder:text-white/30"
                        placeholder="+34 600 000 000"
                      />
                    </div>
                  </div>

                  {/* Row 2: Email & Subject */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                      <Input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        required
                        className="bg-white/5 border-white/10 text-white pl-10 h-11 rounded-xl text-sm placeholder:text-white/30"
                        placeholder="tu@email.com"
                      />
                    </div>
                    <div className="relative">
                      <MessageSquare className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30 z-10" />
                      <Select
                        value={formData.subject}
                        onValueChange={(value) => setFormData({...formData, subject: value})}
                      >
                        <SelectTrigger className="bg-white/5 border-white/10 text-white pl-10 h-11 rounded-xl text-sm">
                          <SelectValue placeholder="Motivo" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="booking">Contratación</SelectItem>
                          <SelectItem value="press">Prensa</SelectItem>
                          <SelectItem value="collaboration">Colaboración</SelectItem>
                          <SelectItem value="fan">Fan</SelectItem>
                          <SelectItem value="other">Otro</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Message */}
                  <Textarea
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    required
                    rows={3}
                    className="bg-white/5 border-white/10 text-white resize-none rounded-xl text-sm placeholder:text-white/30"
                    placeholder="Escribe tu mensaje aquí..."
                  />

                  {/* Submit Button */}
                  <Button
                    type="submit"
                    size="lg"
                    disabled={isSubmitting}
                    className="w-full bg-[#8B1538] hover:bg-[#6A1029] text-white font-medium py-5 rounded-xl text-sm"
                  >
                    {isSubmitting ? (
                      <span className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Enviando...
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        <Send className="w-4 h-4" />
                        Enviar Mensaje
                      </span>
                    )}
                  </Button>

                  {/* Secondary Contact */}
                  <div className="flex justify-center gap-3 pt-2">
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="text-white/50 hover:text-white hover:bg-white/10 rounded-lg text-xs h-8 px-3"
                      asChild
                    >
                      <a href="mailto:contratacionvizcainoreyes@gmail.com">
                        <Mail className="w-3.5 h-3.5 mr-1.5" />
                        Email
                      </a>
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="text-white/50 hover:text-[#25D366] hover:bg-[#25D366]/10 rounded-lg text-xs h-8 px-3"
                      asChild
                    >
                      <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
                        <MessageCircle className="w-3.5 h-3.5 mr-1.5" />
                        WhatsApp
                      </a>
                    </Button>
                  </div>
                </form>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, Disc3, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import LazyImage from '../media/LazyImage';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

export default function ShopSection() {
  const { ref, hasBeenVisible } = useIntersectionObserver({ threshold: 0.1 });

  const { data: sectionBg } = useQuery({
    queryKey: ['shopBackground'],
    queryFn: async () => {
      const items = await base44.entities.SiteContent.filter({ section: 'shop', key: 'background_image' });
      return items[0]?.content_es || null;
    },
    staleTime: 60000,
  });

  const whatsappMessage = encodeURIComponent(
    "¡Hola! Me gustaría comprar el disco 'Identidad' de Vizcaíno Reyes. ¿Podrías darme más información? ¡Gracias!"
  );
  const whatsappUrl = `https://wa.me/34635571408?text=${whatsappMessage}`;

  const trackShopClick = async () => {
    try {
      await base44.entities.Analytics.create({
        event_type: 'shop_click',
        page: 'shop',
        metadata: { action: 'whatsapp_click' }
      });
    } catch (e) {}
  };

  return (
    <section id="shop" className="py-20 md:py-32 bg-black relative overflow-hidden">
      {/* Background Image */}
      {sectionBg && (
        <div className="absolute inset-0 z-0">
          <img src={sectionBg} alt="" className="w-full h-full object-cover opacity-30" />
          <div className="absolute inset-0 bg-black/40" />
        </div>
      )}

      <div className="container mx-auto px-4 relative z-10" ref={ref}>
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={hasBeenVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-10 md:mb-12"
        >
          <span className="text-[#8B1538] uppercase tracking-[0.3em] text-xs font-medium">
            Tienda Oficial
          </span>
          <h2 className="font-heading text-4xl md:text-5xl lg:text-6xl text-white mt-2 md:mt-3">
            CONSIGUE TU DISCO
          </h2>
        </motion.div>

        {/* Product Card */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={hasBeenVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="max-w-3xl mx-auto relative"
        >
          {/* Diagonal Ribbon - Desktop */}
          <div className="hidden md:block absolute -top-2 -right-2 z-20 overflow-hidden w-44 h-44 pointer-events-none">
            <div className="absolute top-9 -right-14 transform rotate-45 bg-[#8B1538] text-white text-xs font-bold py-2 px-14 shadow-lg whitespace-nowrap">
              ¡ÚLTIMAS UNIDADES!
            </div>
          </div>

          {/* Diagonal Ribbon - Mobile */}
          <div className="md:hidden absolute -top-1 -right-1 z-20 overflow-hidden w-32 h-32 pointer-events-none">
            <div className="absolute top-6 -right-10 transform rotate-45 bg-[#8B1538] text-white text-[9px] font-bold py-1.5 px-10 shadow-lg whitespace-nowrap">
              ¡ÚLTIMAS!
            </div>
          </div>

          <div className="bg-white/5 backdrop-blur-sm rounded-xl md:rounded-2xl p-5 md:p-8 border border-white/10">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-10 items-center">
              {/* Vinyl Record */}
              <div className="relative group max-w-xs mx-auto md:max-w-none">
                {/* Glow Effect */}
                <div className="absolute -inset-4 bg-gradient-to-br from-[#8B1538]/20 via-white/5 to-[#8B1538]/10 rounded-full blur-2xl opacity-70" />

                {/* Vinyl Disc Container */}
                <div className="relative aspect-square">
                  {/* Vinyl Record */}
                  <div className="absolute inset-0 rounded-full bg-gradient-to-br from-neutral-900 via-black to-neutral-800 shadow-2xl overflow-hidden">
                    {/* Vinyl grooves effect */}
                    <div className="absolute inset-0 opacity-20" style={{
                      background: 'repeating-radial-gradient(circle at center, transparent 0, transparent 2px, rgba(255,255,255,0.05) 2px, rgba(255,255,255,0.05) 4px)'
                    }} />

                    {/* Center Label Circle */}
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[45%] h-[45%] rounded-full bg-white shadow-xl overflow-hidden border-2 border-neutral-200">
                      <LazyImage
                        src="https://i.scdn.co/image/ab67616d00001e02c9470a25e2eefcd077fe1387"
                        alt="Álbum Identidad"
                        className="w-full h-full object-cover"
                        objectFit="cover"
                      />
                    </div>

                    {/* Center Hole */}
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[12%] h-[12%] rounded-full bg-black shadow-inner border border-neutral-700" />

                    {/* Shine Effect */}
                    <div className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-transparent opacity-30 group-hover:opacity-50 transition-opacity" />
                  </div>
                </div>

                {/* Signed badge */}
                <div className="absolute -bottom-2 -left-2 md:-bottom-3 md:-left-3 bg-white text-black px-3 md:px-4 py-1.5 md:py-2 rounded-full text-xs md:text-sm font-bold flex items-center gap-1.5 md:gap-2 shadow-lg z-20">
                  <Heart className="w-3 h-3 md:w-4 md:h-4 text-[#8B1538]" fill="#8B1538" />
                  Firmado
                </div>
              </div>

              {/* Album Info */}
              <div className="space-y-4 md:space-y-6 text-center md:text-left">
                <div>
                  <span className="text-[#8B1538] uppercase tracking-widest text-xs">Álbum Debut</span>
                  <h3 className="font-heading text-3xl md:text-4xl lg:text-5xl text-white mt-1 md:mt-2">IDENTIDAD</h3>
                </div>

                {/* Price */}
                <div className="flex items-baseline justify-center md:justify-start gap-2">
                  <span className="font-heading text-4xl md:text-5xl text-white">20€</span>
                </div>

                <div className="space-y-2 md:space-y-3 text-white/60 text-xs md:text-sm">
                  <div className="flex items-center justify-center md:justify-start gap-2 md:gap-3">
                    <Disc3 className="w-3.5 h-3.5 md:w-4 md:h-4 text-[#8B1538]" />
                    <span>14 canciones originales</span>
                  </div>
                  <div className="flex items-center justify-center md:justify-start gap-2 md:gap-3">
                    <Heart className="w-3.5 h-3.5 md:w-4 md:h-4 text-[#8B1538]" />
                    <span>Firmado personalmente</span>
                  </div>
                </div>

                <div className="pt-2 md:pt-4">
                  <Button
                    size="lg"
                    className="w-full bg-[#25D366] hover:bg-[#20BD5A] text-white font-medium py-5 md:py-6 text-sm md:text-base rounded-xl group"
                    asChild
                  >
                    <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" onClick={trackShopClick}>
                      <MessageCircle className="w-4 h-4 md:w-5 md:h-5 mr-2 md:mr-3 group-hover:scale-110 transition-transform" />
                      PEDIR POR WHATSAPP
                    </a>
                  </Button>
                  <p className="text-[#25D366] text-xs text-center mt-2 md:mt-3 font-medium">
                    Envíos gratuitos a toda España
                  </p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
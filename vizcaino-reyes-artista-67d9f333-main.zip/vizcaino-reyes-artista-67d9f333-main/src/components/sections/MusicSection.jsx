import React, { useState, useRef, useEffect, memo } from 'react';
import ReactDOM from 'react-dom';
import { Play, X, ExternalLink, Youtube, Music, Sparkles, Headphones, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

const songs = [
  {
    title: 'BÁILAME',
    plays: '50K+',
    description: 'El ritmo que te hará levantarte a bailar',
    cover: 'https://i.scdn.co/image/ab67616d00001e026d22d10c2bedb95ca7c504ff',
    spotifyAlbumId: '5m3LSJFXfJbRECyKMKEIXp',
    youtubeId: 'AbEpwztwKHI',
    duration: '3:24',
    featured: true,
  },
  {
    title: 'AURA',
    plays: '35K+',
    description: 'Nominada Premios Música Aragonesa 2024',
    cover: 'https://i.scdn.co/image/ab67616d00001e02c9470a25e2eefcd077fe1387',
    spotifyAlbumId: '0DHe1PpWcsEKCWkJSBzdcU',
    youtubeId: 'hfpbvqvrvLA',
    duration: '3:45',
    featured: true,
  },
  {
    title: 'Mi Confidente',
    plays: '28K+',
    description: 'La favorita de los fans',
    cover: 'https://i.scdn.co/image/ab67616d00001e02c6b20bc94ed9eecd863cb8aa',
    spotifyAlbumId: '0kTN9dvT4aBQ5qY1FkIRr7',
    youtubeId: '0xP-6GI6_pc',
    duration: '4:02',
    featured: false,
  },
  {
    title: 'Identidad',
    plays: '22K+',
    description: 'El tema que define el álbum',
    cover: 'https://i.scdn.co/image/ab67616d00001e02dcc3f3b0bf0ce812bca1ae9f',
    spotifyAlbumId: '5m3LSJFXfJbRECyKMKEIXp',
    youtubeId: 'AbEpwztwKHI',
    duration: '3:56',
    featured: false,
  },
  {
    title: 'Libre',
    plays: '18K+',
    description: 'Sentimiento puro en cada nota',
    cover: 'https://i.scdn.co/image/ab67616d00001e02f1b0bdd2e6b6765903c13824',
    spotifyAlbumId: '0DHe1PpWcsEKCWkJSBzdcU',
    youtubeId: 'hfpbvqvrvLA',
    duration: '3:18',
    featured: false,
  },
  {
    title: 'Noche Eterna',
    plays: '15K+',
    description: 'Para las noches de reflexión',
    cover: 'https://i.scdn.co/image/ab67616d00001e026d22d10c2bedb95ca7c504ff',
    spotifyAlbumId: '0kTN9dvT4aBQ5qY1FkIRr7',
    youtubeId: '0xP-6GI6_pc',
    duration: '4:12',
    featured: false,
  },
];

// Memoized song card - only re-renders when props change
const SongCard = memo(function SongCard({ song, index, onPlay }) {
  const [imageLoaded, setImageLoaded] = useState(false);
  
  return (
    <article className="group relative">
      {/* Simple Card - No heavy animations on scroll */}
      <div 
        className="relative bg-white/[0.03] rounded-2xl overflow-hidden border border-white/[0.08] hover:border-[#8B1538]/40 transition-colors duration-300 cursor-pointer"
        onClick={() => onPlay(song)}
      >
        {/* Thumbnail Container */}
        <div className="relative aspect-square overflow-hidden bg-black">
          <img
            src={song.cover}
            alt={song.title}
            className={`w-full h-full object-cover transition-all duration-300 group-hover:scale-105 ${imageLoaded ? 'opacity-100' : 'opacity-0'}`}
            loading="lazy"
            decoding="async"
            onLoad={() => setImageLoaded(true)}
          />
          
          {/* Overlay Gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
          
          {/* Play Button - Simple, appears on hover */}
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            <div className="w-14 h-14 md:w-16 md:h-16 rounded-full bg-[#8B1538] flex items-center justify-center shadow-xl">
              <Play className="w-6 h-6 md:w-7 md:h-7 text-white ml-1" fill="white" />
            </div>
          </div>
          
          {/* Duration Badge */}
          <div className="absolute bottom-3 right-3 bg-black/70 px-2 py-1 rounded text-xs text-white/90 font-medium">
            {song.duration}
          </div>
          
          {/* Featured Badge */}
          {song.featured && (
            <div className="absolute top-3 left-3 bg-[#8B1538] px-2.5 py-1 rounded-full text-[10px] text-white font-semibold flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              TOP
            </div>
          )}
        </div>
        
        {/* Content */}
        <div className="p-4 md:p-5">
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3 className="text-white font-semibold text-base md:text-lg truncate group-hover:text-[#8B1538] transition-colors">
              {song.title}
            </h3>
            <span className="flex-shrink-0 text-[10px] bg-white/10 text-white/70 px-2 py-1 rounded-full font-medium flex items-center gap-1">
              <Headphones className="w-3 h-3" />
              {song.plays}
            </span>
          </div>
          <p className="text-white/50 text-xs md:text-sm line-clamp-2">{song.description}</p>
        </div>
      </div>
    </article>
  );
});

function VideoModal({ song, onClose, playerType, setPlayerType }) {
  const [isReady, setIsReady] = useState(false);

  // Prevent body scroll and mark ready
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    setIsReady(true);
    return () => { document.body.style.overflow = ''; };
  }, []);

  const modalContent = (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        zIndex: 99999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '1rem',
        background: 'rgba(0,0,0,0.97)',
      }}
      onClick={onClose}
    >
      {/* Modal Content */}
      <div
        style={{ 
          position: 'relative', 
          width: '100%', 
          maxWidth: '56rem',
          opacity: isReady ? 1 : 0,
          transform: isReady ? 'scale(1)' : 'scale(0.95)',
          transition: 'all 0.2s ease-out'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          style={{
            position: 'absolute',
            top: '-3rem',
            right: 0,
            color: 'rgba(255,255,255,0.7)',
            padding: '0.5rem',
            background: 'transparent',
            border: 'none',
            cursor: 'pointer'
          }}
          onClick={onClose}
        >
          <X className="w-8 h-8" />
        </button>
        
        {/* Song Title */}
        <div className="text-center mb-4">
          <h3 className="text-white font-heading text-2xl md:text-3xl">{song.title}</h3>
          <p className="text-white/50 text-sm mt-1">{song.description}</p>
        </div>
        
        {/* Player Toggle */}
        <div className="flex justify-center gap-3 mb-4">
          <button
            onClick={() => setPlayerType('youtube')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-medium transition-all ${
              playerType === 'youtube' 
                ? 'bg-red-600 text-white' 
                : 'bg-white/10 text-white/60 hover:bg-white/20'
            }`}
          >
            <Youtube className="w-5 h-5" />
            YouTube
          </button>
          <button
            onClick={() => setPlayerType('spotify')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-medium transition-all ${
              playerType === 'spotify' 
                ? 'bg-[#1DB954] text-black' 
                : 'bg-white/10 text-white/60 hover:bg-white/20'
            }`}
          >
            <Music className="w-5 h-5" />
            Spotify
          </button>
        </div>
        
        {/* Player Container */}
        <div className="rounded-2xl overflow-hidden shadow-2xl bg-neutral-900">
          {playerType === 'youtube' && song.youtubeId && (
            <div className="relative aspect-video">
              <iframe
                src={`https://www.youtube.com/embed/${song.youtubeId}?autoplay=1&rel=0`}
                title={song.title}
                className="w-full h-full"
                style={{ border: 'none' }}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          )}

          {playerType === 'spotify' && song.spotifyAlbumId && (
            <iframe
              src={`https://open.spotify.com/embed/album/${song.spotifyAlbumId}?utm_source=generator&theme=0`}
              title={song.title}
              className="w-full"
              height="380"
              style={{ border: 'none' }}
              allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
            />
          )}
        </div>
      </div>
    </div>
  );

  // Render modal using portal to document.body
  return ReactDOM.createPortal(modalContent, document.body);
}

export default function MusicSection() {
    const sectionRef = useRef(null);
    const [playingSong, setPlayingSong] = useState(null);
    const [playerType, setPlayerType] = useState('youtube');
    const [isMobile, setIsMobile] = useState(false);

    useEffect(() => {
      const checkMobile = () => setIsMobile(window.innerWidth < 768);
      checkMobile();
      window.addEventListener('resize', checkMobile, { passive: true });
      return () => window.removeEventListener('resize', checkMobile);
    }, []);

    // Show only 3 songs on mobile
    const displayedSongs = isMobile ? songs.slice(0, 3) : songs;

  const { data: sectionBg } = useQuery({
    queryKey: ['musicBackground'],
    queryFn: async () => {
      const items = await base44.entities.SiteContent.filter({ section: 'music', key: 'background_image' });
      return items[0]?.content_es || null;
    },
    staleTime: 60000,
  });

  return (
    <section id="music" className="relative py-20 md:py-32 overflow-hidden bg-black" ref={sectionRef}>
      {/* Simplified Background - No heavy animations */}
      <div className="absolute inset-0 z-0">
        {/* Base Gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-black via-[#0a0a0a] to-black" />
        
        {/* Background Image with Opacity */}
        {sectionBg && (
          <img src={sectionBg} alt="" className="absolute inset-0 w-full h-full object-cover opacity-20" loading="lazy" />
        )}
        
        {/* Static decorative elements instead of animated ones */}
        <div className="absolute top-20 left-10 w-64 h-64 rounded-full bg-[#8B1538]/10 blur-[100px] pointer-events-none" />
        <div className="absolute bottom-20 right-10 w-80 h-80 rounded-full bg-purple-500/5 blur-[120px] pointer-events-none" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header - Simplified animations */}
        <header className="text-center mb-12 md:mb-16">
          <div className="inline-flex items-center gap-2 bg-[#8B1538]/20 border border-[#8B1538]/30 rounded-full px-4 py-2 mb-4 md:mb-6">
            <Sparkles className="w-4 h-4 text-[#8B1538]" />
            <span className="text-[#8B1538] text-xs md:text-sm font-medium">Top Canciones</span>
          </div>
          
          <h2 className="font-heading text-4xl md:text-5xl lg:text-6xl xl:text-7xl text-white mb-4">
            MÁS <span className="text-[#8B1538]">ESCUCHADO</span>
          </h2>
          
          <p className="text-white/50 max-w-xl mx-auto text-sm md:text-base">
            Las canciones más escuchadas del álbum "Identidad". 
            Haz clic en cualquier canción para reproducirla.
          </p>
        </header>

        {/* Songs Grid - Mobile First */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 max-w-6xl mx-auto mb-12">
          {displayedSongs.map((song, index) => (
            <SongCard 
              key={song.title} 
              song={song} 
              index={index} 
              onPlay={setPlayingSong}
            />
          ))}
        </div>

        {/* Spotify CTA */}
        <div className="text-center">
          <Button
            size="lg"
            className="bg-[#1DB954] hover:bg-[#1ed760] text-black font-semibold px-8 rounded-full shadow-lg shadow-[#1DB954]/20 hover:shadow-[#1DB954]/40 transition-all"
            asChild
          >
            <a href="https://open.spotify.com/intl-es/artist/7a9ocgPbS1GWJ4hfg0SINH" target="_blank" rel="noopener noreferrer">
              <ExternalLink className="w-5 h-5 mr-2" />
              Escuchar en Spotify
            </a>
          </Button>
        </div>
      </div>

      {/* Video Modal - Only renders when song is selected */}
      {playingSong && (
        <VideoModal 
          song={playingSong} 
          onClose={() => setPlayingSong(null)}
          playerType={playerType}
          setPlayerType={setPlayerType}
        />
      )}
    </section>
  );
}
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Youtube, Disc, Award } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import LazyImage from '../media/LazyImage';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

function AnimatedCounter({ value, suffix = '', duration = 2000, start }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!start) return;
    
    let startTime;
    const animate = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * value));
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    requestAnimationFrame(animate);
  }, [start, value, duration]);

  return <>{count.toLocaleString()}{suffix}</>;
}

export default function AboutSection() {
  const { ref, hasBeenVisible } = useIntersectionObserver({ threshold: 0.2 });

  const { data: sectionBg } = useQuery({
    queryKey: ['aboutBackground'],
    queryFn: async () => {
      const items = await base44.entities.SiteContent.filter({ section: 'about', key: 'background_image' });
      return items[0]?.content_es || null;
    },
    staleTime: 60000,
  });

  const stats = [
    { icon: Youtube, value: 250000, suffix: '+', label: 'Reproducciones', animate: true },
    { icon: Disc, value: 500, suffix: '+', label: 'Copias Vendidas', animate: true },
    { icon: Award, value: 1, suffix: 'r', label: 'Disco a mis 20 años', animate: false, displayValue: '1r' },
  ];

  return (
    <section id="about" className="relative bg-black pt-8 md:pt-16">
      {/* Background Image */}
      {sectionBg && (
        <div className="absolute inset-0 z-0">
          <img src={sectionBg} alt="" className="w-full h-full object-cover opacity-25" />
          <div className="absolute inset-0 bg-black/40" />
        </div>
      )}

      <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
        <div ref={ref}>
          {/* Mobile Layout - Image integrated with text */}
          <div className="lg:hidden">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={hasBeenVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8 }}
              className="space-y-6"
            >
              {/* Section title */}
              <div className="text-center">
                <span className="text-[#8B1538] uppercase tracking-[0.3em] text-xs font-medium">
                  Sobre el Artista
                </span>
                <h2 className="font-heading text-4xl text-white mt-2">
                  VIZCAÍNO REYES
                </h2>
              </div>

              {/* Bio with integrated image */}
              <div className="space-y-4 text-white/70 text-sm leading-relaxed">
                {/* Image floated */}
                <div className="float-right ml-4 mb-2 w-28 h-36 rounded-xl overflow-hidden shadow-lg border border-white/10">
                  <LazyImage
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69301d0f84291b4467d9f333/97639e7da_Capturadepantalla2025-12-03121412.png"
                    alt="Vizcaíno Reyes"
                    className="w-full h-full"
                    objectFit="cover"
                  />
                </div>
                <p>
                  <span className="text-white font-medium">Músico y cantante de 21 años</span>, nominado a 
                  "Artista con Mayor Proyección" de Aragón. Mi música fusiona el{' '}
                  <span className="text-[#8B1538]">flamenco moderno</span>, el pop y el urbano.
                </p>
                <p>
                  Con mi disco <span className="text-white font-medium">"Identidad"</span>, nominado a los 
                  Premios de la Música Aragonesa 2024, presento un espectáculo que invita a sentir, 
                  cantar y vivir cada canción desde el corazón.
                </p>
              </div>

              {/* Quote */}
              <div className="border-l-2 border-[#8B1538] pl-4 py-2 clear-both">
                <p className="text-white/90 italic text-base">
                  "La música es el lenguaje del alma."
                </p>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-3 gap-2 pt-4">
                {stats.map((stat) => (
                  <div key={stat.label} className="bg-white/5 rounded-xl p-3 text-center border border-white/10">
                    <stat.icon className="w-4 h-4 text-[#8B1538] mx-auto mb-1.5" />
                    <div className="font-heading text-lg text-white">
                      {stat.displayValue ? stat.displayValue : (
                        stat.animate ? (
                          <AnimatedCounter value={stat.value} suffix={stat.suffix} start={hasBeenVisible} />
                        ) : (
                          `${stat.value}${stat.suffix}`
                        )
                      )}
                    </div>
                    <div className="text-white/40 text-[10px] mt-0.5">{stat.label}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Desktop Layout - Original side by side */}
          <div className="hidden lg:grid lg:grid-cols-2 gap-16 items-center">
            {/* Image */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={hasBeenVisible ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="relative aspect-[3/4] max-w-lg mx-auto">
                <LazyImage
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69301d0f84291b4467d9f333/97639e7da_Capturadepantalla2025-12-03121412.png"
                  alt="Vizcaíno Reyes"
                  className="w-full h-full rounded-2xl"
                  objectFit="cover"
                />
              </div>
            </motion.div>

            {/* Content */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={hasBeenVisible ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="space-y-8"
            >
              {/* Section title */}
              <div>
                <span className="text-[#8B1538] uppercase tracking-[0.3em] text-xs font-medium">
                  Sobre el Artista
                </span>
                <h2 className="font-heading text-5xl lg:text-6xl text-white mt-3">
                  VIZCAÍNO REYES
                </h2>
              </div>

              {/* Bio */}
              <div className="space-y-4 text-white/70 text-base leading-relaxed">
                <p>
                  <span className="text-white font-medium">Músico y cantante de 21 años</span>, nominado a 
                  "Artista con Mayor Proyección" de Aragón. Mi música fusiona el{' '}
                  <span className="text-[#8B1538]">flamenco moderno</span>, el pop y el urbano.
                </p>
                <p>
                  Con mi disco <span className="text-white font-medium">"Identidad"</span>, nominado a los 
                  Premios de la Música Aragonesa 2024, presento un espectáculo que invita a sentir, 
                  cantar y vivir cada canción desde el corazón.
                </p>
              </div>

              {/* Quote */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={hasBeenVisible ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.5 }}
                className="border-l-2 border-[#8B1538] pl-6 py-2"
              >
                <p className="text-white/90 italic text-lg">
                  "La música es el lenguaje del alma."
                </p>
              </motion.div>

              {/* Stats Grid */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={hasBeenVisible ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.6 }}
                className="grid grid-cols-3 gap-4 pt-6"
              >
                {stats.map((stat) => (
                  <div key={stat.label} className="bg-white/5 rounded-2xl p-4 text-center border border-white/10">
                    <stat.icon className="w-5 h-5 text-[#8B1538] mx-auto mb-2" />
                    <div className="font-heading text-2xl text-white">
                      {stat.displayValue ? stat.displayValue : (
                        stat.animate ? (
                          <AnimatedCounter value={stat.value} suffix={stat.suffix} start={hasBeenVisible} />
                        ) : (
                          `${stat.value}${stat.suffix}`
                        )
                      )}
                    </div>
                    <div className="text-white/40 text-xs mt-1">{stat.label}</div>
                  </div>
                ))}
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
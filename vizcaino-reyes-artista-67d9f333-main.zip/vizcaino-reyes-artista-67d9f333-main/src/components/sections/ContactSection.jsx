import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, Mail, Phone, User, MessageSquare, CheckCircle, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

export default function ContactSection() {
  const { ref, hasBeenVisible } = useIntersectionObserver({ threshold: 0.1 });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'booking',
    message: '',
  });

  const { data: sectionBg } = useQuery({
    queryKey: ['contactBackground'],
    queryFn: async () => {
      const items = await base44.entities.SiteContent.filter({ section: 'contact', key: 'background_image' });
      return items[0]?.content_es || null;
    },
    staleTime: 60000,
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    await base44.entities.ContactMessage.create({
      ...formData,
      status: 'pending',
    });
    
    await base44.entities.Analytics.create({
      event_type: 'contact_form_submit',
      page: 'contact',
      metadata: { subject: formData.subject }
    });
    
    setIsSuccess(true);
    setFormData({ name: '', email: '', phone: '', subject: 'booking', message: '' });
    setIsSubmitting(false);
  };
  
  const trackFormStart = async () => {
    try {
      await base44.entities.Analytics.create({
        event_type: 'contact_form_start',
        page: 'contact'
      });
    } catch (e) {}
  };

  const whatsappMessage = encodeURIComponent("¡Hola! Me gustaría ponerme en contacto contigo.");
  const whatsappUrl = `https://wa.me/34635571408?text=${whatsappMessage}`;

  return (
    <section id="contact" className="py-20 md:py-32 relative" style={{ backgroundColor: '#000000' }}>
      {/* Background Image with Opacity */}
      {sectionBg && (
                <div className="absolute inset-0 z-0">
                  <img src={sectionBg} alt="" className="w-full h-full object-cover opacity-50" />
                  <div className="absolute inset-0 bg-black/40" />
                </div>
              )}
      {!sectionBg && <div className="absolute inset-0 bg-black" style={{ zIndex: -1 }} />}

      <div className="container mx-auto px-4 relative z-10" ref={ref}>
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={hasBeenVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-10 md:mb-12"
        >
          <span className="text-[#8B1538] uppercase tracking-[0.3em] text-xs font-medium">
            Contacto
          </span>
          <h2 className="font-heading text-4xl md:text-5xl lg:text-6xl text-white mt-3">
            Haz Realidad Tu Evento
          </h2>
          <p className="text-white/50 mt-3 text-sm md:text-base">
            Contrataciones y colaboraciones
          </p>
        </motion.div>

        {/* Compact Form Card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={hasBeenVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-xl mx-auto"
        >
          <div className="bg-[#0d0d0d]/80 backdrop-blur-sm rounded-2xl md:rounded-3xl p-6 md:p-8 border border-white/10">
            {isSuccess ? (
              <div className="text-center py-6 md:py-8">
                <CheckCircle className="w-14 h-14 md:w-16 md:h-16 text-green-500 mx-auto mb-4" />
                <h3 className="font-heading text-xl md:text-2xl text-white mb-2">¡Mensaje Enviado!</h3>
                <p className="text-white/60 mb-6 text-sm md:text-base">Te responderé lo antes posible.</p>
                <Button
                  className="bg-white/10 hover:bg-white/20 rounded-xl"
                  onClick={() => setIsSuccess(false)}
                >
                  Enviar otro mensaje
                </Button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4" onFocus={trackFormStart}>
                {/* Row 1: Name & Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4">
                  <div className="relative">
                    <User className="absolute left-3 md:left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                    <Input
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      required
                      className="bg-white/5 border-white/10 text-white pl-10 md:pl-11 h-11 md:h-12 rounded-xl text-sm placeholder:text-white/30"
                      placeholder="Nombre"
                    />
                  </div>
                  <div className="relative">
                    <Phone className="absolute left-3 md:left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                    <Input
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      className="bg-white/5 border-white/10 text-white pl-10 md:pl-11 h-11 md:h-12 rounded-xl text-sm placeholder:text-white/30"
                      placeholder="+34 600 000 000"
                    />
                  </div>
                </div>

                {/* Row 2: Email & Subject */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4">
                  <div className="relative">
                    <Mail className="absolute left-3 md:left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                    <Input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      required
                      className="bg-white/5 border-white/10 text-white pl-10 md:pl-11 h-11 md:h-12 rounded-xl text-sm placeholder:text-white/30"
                      placeholder="tu@email.com"
                    />
                  </div>
                  <div className="relative">
                    <MessageSquare className="absolute left-3 md:left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30 z-10" />
                    <Select
                      value={formData.subject}
                      onValueChange={(value) => setFormData({...formData, subject: value})}
                    >
                      <SelectTrigger className="bg-white/5 border-white/10 text-white pl-10 md:pl-11 h-11 md:h-12 rounded-xl text-sm">
                        <SelectValue placeholder="Motivo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="booking">Contratación</SelectItem>
                        <SelectItem value="press">Prensa</SelectItem>
                        <SelectItem value="collaboration">Colaboración</SelectItem>
                        <SelectItem value="fan">Fan</SelectItem>
                        <SelectItem value="other">Otro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Message */}
                <Textarea
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  required
                  rows={3}
                  className="bg-white/5 border-white/10 text-white resize-none rounded-xl text-sm placeholder:text-white/30"
                  placeholder="Escribe tu mensaje aquí..."
                />

                {/* Submit Button */}
                <Button
                  type="submit"
                  size="lg"
                  disabled={isSubmitting}
                  className="w-full bg-[#8B1538] hover:bg-[#6A1029] text-white font-medium py-5 md:py-6 rounded-xl text-sm md:text-base"
                >
                  {isSubmitting ? (
                    <span className="flex items-center gap-2">
                      <div className="w-4 h-4 md:w-5 md:h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Enviando...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      <Send className="w-4 h-4 md:w-5 md:h-5" />
                      Enviar Mensaje
                    </span>
                  )}
                </Button>

                {/* Secondary Contact Buttons - Smaller */}
                <div className="flex justify-center gap-3 pt-2">
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="text-white/50 hover:text-white hover:bg-white/10 rounded-lg text-xs h-8 px-3"
                    asChild
                  >
                    <a href="mailto:contratacionvizcainoreyes@gmail.com">
                      <Mail className="w-3.5 h-3.5 mr-1.5" />
                      Email
                    </a>
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="text-white/50 hover:text-[#25D366] hover:bg-[#25D366]/10 rounded-lg text-xs h-8 px-3"
                    asChild
                  >
                    <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
                      <MessageCircle className="w-3.5 h-3.5 mr-1.5" />
                      WhatsApp
                    </a>
                  </Button>
                </div>
              </form>
            )}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
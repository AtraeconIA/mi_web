import React from 'react';
import { motion } from 'framer-motion';
import { Play } from 'lucide-react';
import { Button } from '@/components/ui/button';
import OptimizedBackground from '../media/OptimizedBackground';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

export default function HeroSection() {
  const { data: heroContent = [] } = useQuery({
    queryKey: ['heroContent'],
    queryFn: () => base44.entities.SiteContent.filter({ section: 'hero' }, 'order'),
    staleTime: 60000,
  });

  const backgroundItem = heroContent.find(c => c.key === 'background_image');
  const backgroundUrl = backgroundItem?.content_es || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69301d0f84291b4467d9f333/dc3e966d2_Capturadepantalla2025-12-03121458.png';
  const isGrayscale = backgroundItem?.is_grayscale || false;
  const isVideo = backgroundUrl.includes('.mp4') || backgroundUrl.includes('.webm');

  const scrollToSection = (href) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="hero" className="h-screen h-[100dvh] min-h-[500px] flex items-center justify-center">
      {/* Background */}
      <OptimizedBackground
        type={isVideo ? 'video' : 'image'}
        src={backgroundUrl}
        overlayColor="black"
        overlayOpacity={0.55}
        className={`absolute inset-0 ${isGrayscale ? 'grayscale' : ''}`}
        priority
      />

      {/* Gradient overlays */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/50" />

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4">
        <div className="max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
          >
            {/* Main Title */}
            <h1 className="font-heading text-5xl sm:text-6xl md:text-7xl lg:text-8xl text-white tracking-tight leading-[0.9] mb-4">
              VIZCAÍNO<br />
              <span className="text-[#8B1538]">REYES</span>
            </h1>

            {/* Subtitle */}
            <p className="text-white/70 text-base md:text-lg mb-2 max-w-lg">
              Flamenco, urbano y corazón en directo. Una experiencia musical única que conecta con el alma.
            </p>

            {/* Tour info - Gray professional color */}
            <p className="text-[#6B7280] text-xs md:text-sm uppercase tracking-[0.2em] mb-8">
              Temporada 2026 · Gira Identidad
            </p>

            {/* CTA */}
            <Button
              size="lg"
              className="bg-[#8B1538]/90 hover:bg-[#8B1538] text-white font-medium px-6 md:px-8 py-5 md:py-6 text-sm md:text-base tracking-wider rounded-xl group"
              onClick={() => scrollToSection('#music')}
            >
              <Play className="w-4 h-4 md:w-5 md:h-5 mr-2 group-hover:scale-110 transition-transform" fill="white" />
              ESCUCHAR AHORA
            </Button>
          </motion.div>
        </div>
      </div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent" />
    </section>
  );
}
import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, X, Camera, ExternalLink } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

// Lazy video player - only loads video on click
function GalleryModal({ item, onClose }) {
  const [isLoading, setIsLoading] = useState(true);
  const videoRef = useRef(null);
  
  const hasInstagram = item.instagram_url;
  const hasVideo = item.video_url;
  const isVideoItem = item.type === 'video' || hasVideo || hasInstagram;
  
  // Extract Instagram embed URL from reel/post URL
  const getInstagramEmbedUrl = (url) => {
    if (!url) return null;
    // Convert instagram.com/reel/XXX or instagram.com/p/XXX to embed URL
    const match = url.match(/instagram\.com\/(reel|p)\/([^/?]+)/);
    if (match) {
      return `https://www.instagram.com/${match[1]}/${match[2]}/embed`;
    }
    return null;
  };
  
  const instagramEmbedUrl = getInstagramEmbedUrl(hasInstagram);
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="relative max-w-xs md:max-w-sm w-full"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          className="absolute -top-10 right-0 text-white hover:text-[#8B1538] transition-colors"
          onClick={onClose}
        >
          <X className="w-7 h-7" />
        </button>
        
        <h3 className="text-white font-heading text-xl md:text-2xl mb-4 text-center">{item.title}</h3>
        
        {/* Vertical/Portrait container for Instagram-style content */}
        <div className="relative aspect-[9/16] rounded-2xl overflow-hidden shadow-2xl bg-neutral-900">
          {/* Instagram embed */}
          {hasInstagram && !hasVideo && instagramEmbedUrl ? (
            <>
              {isLoading && (
                <div className="absolute inset-0 flex items-center justify-center bg-neutral-900">
                  <div className="w-10 h-10 border-2 border-white border-t-transparent rounded-full animate-spin" />
                </div>
              )}
              <iframe
                src={instagramEmbedUrl}
                className="w-full h-full border-0"
                allowFullScreen
                scrolling="no"
                onLoad={() => setIsLoading(false)}
              />
            </>
          ) : isVideoItem && hasVideo ? (
            <>
              {/* Show thumbnail as poster until video loads */}
              {isLoading && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <img
                    src={item.thumbnail_url}
                    alt={item.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <div className="w-10 h-10 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  </div>
                </div>
              )}
              <video
                ref={videoRef}
                src={item.video_url}
                poster={item.thumbnail_url}
                className="w-full h-full object-cover"
                controls
                autoPlay
                playsInline
                preload="none"
                onLoadedData={() => setIsLoading(false)}
                onCanPlay={() => setIsLoading(false)}
              />
            </>
          ) : (
            <img
              src={item.thumbnail_url}
              alt={item.title}
              className="w-full h-full object-cover"
            />
          )}
        </div>
        
        {/* Instagram link button if available */}
        {hasInstagram && (
          <a
            href={item.instagram_url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 mt-4 bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500 text-white py-3 rounded-xl font-medium text-sm hover:opacity-90 transition-opacity"
          >
            <ExternalLink className="w-4 h-4" />
            Ver en Instagram
          </a>
        )}
      </motion.div>
    </motion.div>
  );
}

const defaultItems = [
  { id: '1', title: 'En Concierto', thumbnail_url: 'https://i.scdn.co/image/ab67616d00001e026d22d10c2bedb95ca7c504ff', type: 'video' },
  { id: '2', title: 'Backstage', thumbnail_url: 'https://i.scdn.co/image/ab67616d00001e02c9470a25e2eefcd077fe1387', type: 'video' },
  { id: '3', title: 'Sesión Foto', thumbnail_url: 'https://i.scdn.co/image/ab67616d00001e02c6b20bc94ed9eecd863cb8aa', type: 'video' },
  { id: '4', title: 'Live Show', thumbnail_url: 'https://i.scdn.co/image/ab67616d00001e02dcc3f3b0bf0ce812bca1ae9f', type: 'video' },
  { id: '5', title: 'Ensayo', thumbnail_url: 'https://i.scdn.co/image/ab67616d00001e02f1b0bdd2e6b6765903c13824', type: 'video' },
  { id: '6', title: 'Acústico', thumbnail_url: 'https://i.scdn.co/image/ab67616d00001e026d22d10c2bedb95ca7c504ff', type: 'video' },
  { id: '7', title: 'Festival', thumbnail_url: 'https://i.scdn.co/image/ab67616d00001e02c9470a25e2eefcd077fe1387', type: 'video' },
  { id: '8', title: 'Estudio', thumbnail_url: 'https://i.scdn.co/image/ab67616d00001e02c6b20bc94ed9eecd863cb8aa', type: 'video' },
];

function IPhoneMockup({ item, onClick, rotation = 0 }) {
  const isVideo = item.type === 'video' || item.video_url || item.instagram_url;
  
  return (
    <div 
      className="flex-shrink-0 cursor-pointer group"
      style={{ 
        transform: `rotate(${rotation}deg)`,
      }}
      onClick={(e) => {
        e.stopPropagation();
        onClick(item);
      }}
    >
      {/* iPhone 15 Pro Frame - Responsive sizing */}
      <div className="relative bg-gradient-to-b from-[#2a2a2a] to-[#1a1a1a] rounded-[28px] md:rounded-[36px] p-[4px] md:p-[6px] shadow-2xl shadow-black/70 w-[120px] md:w-[160px]">
        {/* Titanium edge effect */}
        <div className="absolute inset-0 rounded-[28px] md:rounded-[36px] border border-white/10" />
        
        {/* Dynamic Island */}
        <div className="absolute top-[8px] md:top-[12px] left-1/2 -translate-x-1/2 w-[45px] md:w-[60px] h-[15px] md:h-[20px] bg-black rounded-full z-20" />
        
        {/* Screen */}
        <div className="relative rounded-[24px] md:rounded-[30px] overflow-hidden bg-neutral-900 aspect-[9/19.5]">
          <img
            src={item.thumbnail_url}
            alt={item.title}
            className="w-full h-full object-cover"
            loading="lazy"
            decoding="async"
          />
          
          {/* Play Button - Center, only on hover for videos */}
          {isVideo && (
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/40">
              <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-[#8B1538] flex items-center justify-center shadow-lg">
                <Play className="w-4 h-4 md:w-5 md:h-5 text-white ml-0.5" fill="white" />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function GallerySection() {
  const { ref, hasBeenVisible } = useIntersectionObserver({ threshold: 0.1 });
  const [selectedItem, setSelectedItem] = useState(null);

  const { data: sectionBg } = useQuery({
    queryKey: ['galleryBackground'],
    queryFn: async () => {
      const items = await base44.entities.SiteContent.filter({ section: 'gallery', key: 'background_image' });
      return items[0]?.content_es || null;
    },
    staleTime: 60000,
  });

  const { data: galleryItems = [] } = useQuery({
    queryKey: ['videoGallery'],
    queryFn: () => base44.entities.VideoGallery.filter({ is_active: true }, 'order'),
    staleTime: 60000,
  });

  const items = galleryItems.length > 0 ? galleryItems : defaultItems;
  
  // Triple the items to ensure truly infinite seamless loop (3 complete sets)
  const tripleItems = [...items, ...items, ...items];
  
  // More varied rotations for dynamic look
  const rotations = [-12, -6, 0, 6, 12, -8, 4, -4, 8, -10, 5, -3, 10, -5, 3, -12, -6, 0, 6, 12];

  return (
    <section id="gallery" className="py-20 md:py-32 bg-black overflow-hidden relative">
      {/* Background Image */}
      {sectionBg && (
        <div className="absolute inset-0 z-0">
          <img src={sectionBg} alt="" className="w-full h-full object-cover opacity-25" />
          <div className="absolute inset-0 bg-black/40" />
        </div>
      )}

      <div className="container mx-auto px-4 mb-10 md:mb-16 relative z-10" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={hasBeenVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto"
        >
          <div className="inline-flex items-center gap-2 bg-[#8B1538]/20 border border-[#8B1538]/30 rounded-full px-4 py-2 mb-4 md:mb-6">
            <Camera className="w-4 h-4 text-[#8B1538]" />
            <span className="text-[#8B1538] text-xs md:text-sm font-medium">Galería</span>
          </div>
          <h2 className="font-heading text-4xl md:text-5xl lg:text-6xl text-white">
            CONCIERTOS <span className="text-[#8B1538]">INOLVIDABLES</span>
          </h2>
          <p className="text-white/60 mt-4 md:mt-6 text-sm md:text-base leading-relaxed max-w-xl mx-auto">
            Revive los mejores momentos de conciertos, sesiones de fotos y backstage. 
            Toca cualquier imagen para verla en detalle.
          </p>
          <div className="flex items-center justify-center gap-6 mt-6">
            <div className="text-center">
              <span className="text-2xl md:text-3xl font-heading text-white">2h</span>
              <p className="text-white/40 text-xs mt-1">por Concierto</p>
            </div>
            <div className="w-px h-8 bg-white/20" />
            <div className="text-center">
              <span className="text-2xl md:text-3xl font-heading text-[#8B1538]">∞</span>
              <p className="text-white/40 text-xs mt-1">Recuerdos</p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Infinite Scroll Gallery - Right to Left Movement */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={hasBeenVisible ? { opacity: 1 } : {}}
        transition={{ duration: 0.8, delay: 0.3 }}
        className="relative py-8 md:py-16 z-10 overflow-hidden"
      >
        <style>
          {`
            @keyframes scrollLeftInfinite {
              0% { transform: translateX(0); }
              100% { transform: translateX(-33.333%); }
            }
            .gallery-scroll-infinite {
              animation: scrollLeftInfinite 30s linear infinite;
              will-change: transform;
            }
            @media (min-width: 768px) {
              .gallery-scroll-infinite:hover {
                animation-play-state: paused;
              }
            }
            @media (max-width: 767px) {
              .gallery-scroll-infinite {
                animation-duration: 20s;
              }
            }
          `}
        </style>
        <div 
          className="flex items-center gap-3 md:gap-6 gallery-scroll-infinite"
          style={{ width: 'max-content' }}
        >
          {tripleItems.map((item, index) => (
            <IPhoneMockup 
              key={`${item.id}-${index}`} 
              item={item} 
              onClick={setSelectedItem}
              rotation={rotations[index % rotations.length]}
            />
          ))}
        </div>
        
        {/* Gradient fades - stronger for cleaner edges */}
        <div className="absolute left-0 top-0 bottom-0 w-16 md:w-32 bg-gradient-to-r from-black via-black/80 to-transparent pointer-events-none z-10" />
        <div className="absolute right-0 top-0 bottom-0 w-16 md:w-32 bg-gradient-to-l from-black via-black/80 to-transparent pointer-events-none z-10" />
      </motion.div>

      {/* Expanded View Modal - Vertical/Portrait orientation */}
      <AnimatePresence>
        {selectedItem && (
          <GalleryModal item={selectedItem} onClose={() => setSelectedItem(null)} />
        )}
      </AnimatePresence>
    </section>
  );
}
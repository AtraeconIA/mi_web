import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, MapPin, Clock, Ticket } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTranslation } from '../common/LanguageContext';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

export default function EventsSection() {
  const { t, language } = useTranslation();
  const { ref, hasBeenVisible } = useIntersectionObserver({ threshold: 0.1 });

  const { data: events = [] } = useQuery({
    queryKey: ['events'],
    queryFn: () => base44.entities.Event.filter({ date: { $gte: new Date().toISOString().split('T')[0] } }, 'date'),
  });

  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    const options = { day: 'numeric', month: 'long', year: 'numeric' };
    return date.toLocaleDateString(language === 'es' ? 'es-ES' : 'en-US', options);
  };

  const getMonthDay = (dateStr) => {
    const date = new Date(dateStr);
    return {
      month: date.toLocaleDateString(language === 'es' ? 'es-ES' : 'en-US', { month: 'short' }).toUpperCase(),
      day: date.getDate(),
    };
  };

  return (
    <section id="events" className="py-24 bg-black relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 relative z-10" ref={ref}>
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={hasBeenVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500 uppercase tracking-[0.2em] text-sm font-bold">
            En Vivo
          </span>
          <h2 className="font-heading text-4xl md:text-5xl lg:text-6xl text-white mt-4">
            {t('events.title')}
          </h2>
        </motion.div>

        {/* Events List */}
        {events.length > 0 ? (
          <div className="max-w-4xl mx-auto space-y-6">
            {events.map((event, index) => {
              const { month, day } = getMonthDay(event.date);
              return (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, x: -30 }}
                  animate={hasBeenVisible ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:border-primary/30 transition-colors group"
                >
                  <div className="flex flex-col md:flex-row md:items-center gap-6">
                    {/* Date */}
                    <div className="flex-shrink-0 text-center md:w-20">
                      <div className="text-primary text-sm font-medium">{month}</div>
                      <div className="font-heading text-4xl text-white">{day}</div>
                    </div>

                    {/* Divider */}
                    <div className="hidden md:block w-px h-16 bg-white/10" />

                    {/* Info */}
                    <div className="flex-grow">
                      <h3 className="font-heading text-2xl text-white mb-2 group-hover:text-primary transition-colors">
                        {event.title}
                      </h3>
                      <div className="flex flex-wrap gap-4 text-white/60 text-sm">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          {event.venue}, {event.city}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {event.time}h
                        </span>
                      </div>
                    </div>

                    {/* CTA */}
                    <div className="flex-shrink-0">
                      {event.isSoldOut ? (
                        <span className="px-6 py-3 rounded-lg bg-white/10 text-white/50 font-medium">
                          {t('events.sold_out')}
                        </span>
                      ) : (
                        <Button
                          className="bg-primary hover:bg-primary/90 text-black font-semibold"
                          asChild
                        >
                          <a href={event.ticketUrl} target="_blank" rel="noopener noreferrer">
                            <Ticket className="w-4 h-4 mr-2" />
                            {t('events.tickets')}
                          </a>
                        </Button>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={hasBeenVisible ? { opacity: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-center py-12"
          >
            <Calendar className="w-16 h-16 text-white/20 mx-auto mb-4" />
            <p className="text-white/50 text-lg">{t('events.no_events')}</p>
          </motion.div>
        )}
      </div>
    </section>
  );
}
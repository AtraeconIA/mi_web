import React, { memo } from 'react';
import { useIsMobile } from '../hooks/useMediaQuery';
import LazyImage from './LazyImage';
import LazyVideo from './LazyVideo';
import { cn } from '@/lib/utils';

const OptimizedBackground = memo(function OptimizedBackground({
  type = 'image',
  src,
  srcMobile,
  videoSrc,
  videoSrcMobile,
  poster,
  posterMobile,
  overlayColor = 'black',
  overlayOpacity = 0.5,
  className,
  children,
  priority = false,
}) {
  const isMobile = useIsMobile();

  const currentSrc = isMobile && srcMobile ? srcMobile : src;
  const currentVideoSrc = isMobile && videoSrcMobile ? videoSrcMobile : videoSrc;
  const currentPoster = isMobile && posterMobile ? posterMobile : poster;

  return (
    <div className={cn('relative overflow-hidden transform-gpu', className)}>
      {/* Background Media */}
      {type === 'video' ? (
        <LazyVideo
          src={currentVideoSrc || currentSrc}
          poster={currentPoster}
          autoPlayOnVisible
          loop
          muted
          priority={priority}
          className="absolute inset-0 w-full h-full"
        />
      ) : (
        <LazyImage
          src={currentSrc}
          srcMobile={srcMobile}
          alt="Background"
          priority={priority}
          className="absolute inset-0 w-full h-full"
          objectFit="cover"
        />
      )}

      {/* Overlay */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{ 
          backgroundColor: overlayColor,
          opacity: overlayOpacity 
        }}
      />

      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
});

export default OptimizedBackground;
import React, { useState, useEffect } from 'react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { useIsMobile } from '../hooks/useMediaQuery';
import { cn } from '@/lib/utils';

export default function LazyImage({
  src,
  srcMobile,
  alt,
  className,
  priority = false,
  aspectRatio = 'auto',
  objectFit = 'cover',
  ...props
}) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const { ref, hasBeenVisible } = useIntersectionObserver({ threshold: 0.1 });
  const isMobile = useIsMobile();

  const imageSrc = isMobile && srcMobile ? srcMobile : src;
  const shouldLoad = priority || hasBeenVisible;

  // Preload priority images immediately
  useEffect(() => {
    if (priority && imageSrc) {
      const link = document.createElement('link');
      link.rel = 'preload';
      link.as = 'image';
      link.href = imageSrc;
      link.fetchPriority = 'high';
      document.head.appendChild(link);
      return () => document.head.removeChild(link);
    }
  }, [priority, imageSrc]);

  return (
    <div 
      ref={ref}
      className={cn(
        'relative overflow-hidden bg-neutral-900',
        className
      )}
      style={{ aspectRatio }}
      {...props}
    >
      {/* Skeleton placeholder - dark to avoid flash */}
      {!isLoaded && !hasError && (
        <div className="absolute inset-0 bg-black" />
      )}
      
      {/* Image */}
      {shouldLoad && !hasError && (
        <img
          src={imageSrc}
          alt={alt}
          className={cn(
            'w-full h-full transition-opacity duration-300',
            isLoaded ? 'opacity-100' : 'opacity-0'
          )}
          style={{ objectFit }}
          onLoad={() => setIsLoaded(true)}
          onError={() => setHasError(true)}
          loading={priority ? 'eager' : 'lazy'}
          decoding="async"
          fetchPriority={priority ? 'high' : 'low'}
        />
      )}

      {/* Error state */}
      {hasError && (
        <div className="absolute inset-0 flex items-center justify-center bg-neutral-800 text-neutral-500">
          <span className="text-sm">Error al cargar imagen</span>
        </div>
      )}
    </div>
  );
}
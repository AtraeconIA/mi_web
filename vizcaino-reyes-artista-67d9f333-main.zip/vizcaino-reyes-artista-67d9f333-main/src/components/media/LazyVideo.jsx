import React, { useState, useRef, useEffect } from 'react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { cn } from '@/lib/utils';
import { Play } from 'lucide-react';

export default function LazyVideo({
  src,
  poster,
  autoPlayOnVisible = true,
  loop = true,
  muted = true,
  controls = false,
  priority = false,
  className,
  overlayClassName,
  children,
  ...props
}) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const videoRef = useRef(null);
  const { ref, isVisible, hasBeenVisible } = useIntersectionObserver({ threshold: 0.1 });
  
  // For priority videos, always render immediately
  const shouldRender = priority || hasBeenVisible;

  // Auto-play for priority videos immediately
  useEffect(() => {
    if (priority && videoRef.current) {
      // Force load and play for priority videos
      videoRef.current.load();
      const playPromise = videoRef.current.play();
      if (playPromise !== undefined) {
        playPromise.then(() => {
          setIsPlaying(true);
          setIsLoaded(true);
        }).catch(() => {
          // Autoplay was prevented, set loaded anyway
          setIsLoaded(true);
        });
      }
    }
  }, [priority]);

  useEffect(() => {
    if (!videoRef.current || priority) return;

    if (isVisible && autoPlayOnVisible && isLoaded) {
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    } else if (!isVisible && isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  }, [isVisible, autoPlayOnVisible, isLoaded, priority]);

  const handlePlayClick = () => {
    if (videoRef.current) {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  return (
    <div ref={ref} className={cn('relative overflow-hidden bg-black', className)} {...props}>
      {/* Dark background while loading - prevents white flash */}
      {!isLoaded && (
        <div className="absolute inset-0 bg-black" />
      )}
      
      {/* Poster while loading */}
      {poster && !isLoaded && (
        <img 
          src={poster} 
          alt="Video poster"
          className="absolute inset-0 w-full h-full object-cover"
          loading="eager"
        />
      )}

      {/* Video - Priority loads immediately, others when visible */}
      {shouldRender && (
        <video
          ref={videoRef}
          src={src}
          poster={poster}
          loop={loop}
          muted={muted}
          controls={controls}
          playsInline
          autoPlay={priority}
          preload={priority ? "auto" : "none"}
          className={cn(
            'w-full h-full object-cover transition-opacity duration-300',
            isLoaded ? 'opacity-100' : 'opacity-0'
          )}
          onLoadedData={() => setIsLoaded(true)}
          onCanPlay={() => priority && setIsLoaded(true)}
        />
      )}

      {/* Play button overlay (if not autoplay) */}
      {!autoPlayOnVisible && !isPlaying && isLoaded && (
        <button
          onClick={handlePlayClick}
          className="absolute inset-0 flex items-center justify-center bg-black/30 transition-opacity hover:bg-black/40"
        >
          <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
            <Play className="w-8 h-8 text-white ml-1" fill="white" />
          </div>
        </button>
      )}

      {/* Overlay for content */}
      {children && (
        <div className={cn('absolute inset-0', overlayClassName)}>
          {children}
        </div>
      )}
    </div>
  );
}
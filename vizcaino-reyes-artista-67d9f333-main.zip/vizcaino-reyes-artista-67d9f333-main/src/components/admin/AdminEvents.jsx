import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, Plus, Pencil, Trash2, Save, X, MapPin, Clock, Link } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function AdminEvents() {
  const [editingEvent, setEditingEvent] = useState(null);
  const [isCreating, setIsCreating] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    date: '',
    time: '',
    venue: '',
    city: '',
    ticket_url: '',
    is_sold_out: false,
  });

  const queryClient = useQueryClient();

  const { data: events = [], isLoading } = useQuery({
    queryKey: ['events'],
    queryFn: () => base44.entities.Event.list('-date'),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Event.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['events'] });
      resetForm();
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Event.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['events'] });
      resetForm();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Event.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['events'] }),
  });

  const resetForm = () => {
    setFormData({ title: '', date: '', time: '', venue: '', city: '', ticket_url: '', is_sold_out: false });
    setEditingEvent(null);
    setIsCreating(false);
  };

  const handleEdit = (event) => {
    setFormData({
      title: event.title,
      date: event.date,
      time: event.time || '',
      venue: event.venue,
      city: event.city,
      ticket_url: event.ticket_url || '',
      is_sold_out: event.is_sold_out || false,
    });
    setEditingEvent(event);
    setIsCreating(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingEvent) {
      updateMutation.mutate({ id: editingEvent.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-heading text-white mb-2">Eventos</h2>
          <p className="text-white/60">Gestiona tus conciertos y eventos</p>
        </div>
        <Button
          onClick={() => { setIsCreating(true); setEditingEvent(null); }}
          className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-bold"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nuevo Evento
        </Button>
      </div>

      {/* Form */}
      {(isCreating || editingEvent) && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="bg-white/5 border-white/10">
            <CardHeader>
              <CardTitle className="text-white flex items-center justify-between">
                {editingEvent ? 'Editar Evento' : 'Nuevo Evento'}
                <Button variant="ghost" size="icon" onClick={resetForm}>
                  <X className="w-4 h-4" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  placeholder="Título del evento"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="bg-white/5 border-white/10 text-white"
                  required
                />
                <Input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="bg-white/5 border-white/10 text-white"
                  required
                />
                <Input
                  placeholder="Hora (ej: 21:00)"
                  value={formData.time}
                  onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                  className="bg-white/5 border-white/10 text-white"
                />
                <Input
                  placeholder="Lugar"
                  value={formData.venue}
                  onChange={(e) => setFormData({ ...formData, venue: e.target.value })}
                  className="bg-white/5 border-white/10 text-white"
                  required
                />
                <Input
                  placeholder="Ciudad"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  className="bg-white/5 border-white/10 text-white"
                  required
                />
                <Input
                  placeholder="URL de entradas (ej: https://...)"
                  value={formData.ticket_url}
                  onChange={(e) => setFormData({ ...formData, ticket_url: e.target.value })}
                  className="bg-white/5 border-white/10 text-white"
                />
                <div className="flex items-center gap-3">
                  <Switch
                    checked={formData.is_sold_out}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_sold_out: checked })}
                  />
                  <span className="text-white/60">Agotado</span>
                </div>
                <div className="md:col-span-2 flex justify-end gap-3">
                  <Button type="button" variant="outline" onClick={resetForm} className="border-white/20 text-white">
                    Cancelar
                  </Button>
                  <Button type="submit" className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-bold">
                    <Save className="w-4 h-4 mr-2" />
                    {editingEvent ? 'Guardar Cambios' : 'Crear Evento'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Events List */}
      <div className="grid gap-4">
        {events.map((event) => (
          <Card key={event.id} className="bg-white/5 border-white/10">
            <CardContent className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="text-center px-4 py-2 bg-gradient-to-r from-yellow-400/20 to-orange-500/20 rounded-lg">
                  <div className="text-yellow-400 text-xs font-bold">
                    {new Date(event.date).toLocaleDateString('es-ES', { month: 'short' }).toUpperCase()}
                  </div>
                  <div className="text-white text-2xl font-heading">
                    {new Date(event.date).getDate()}
                  </div>
                </div>
                <div>
                  <h3 className="text-white font-semibold text-lg">{event.title}</h3>
                  <div className="flex items-center gap-3 text-white/50 text-sm">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3" /> {event.venue}, {event.city}
                    </span>
                    {event.time && (
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {event.time}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {event.is_sold_out && (
                  <span className="px-3 py-1 bg-red-500/20 text-red-400 rounded-full text-xs font-medium">
                    Agotado
                  </span>
                )}
                {event.ticket_url && (
                  <a href={event.ticket_url} target="_blank" rel="noopener noreferrer">
                    <Button variant="ghost" size="icon" className="text-white/50 hover:text-white">
                      <Link className="w-4 h-4" />
                    </Button>
                  </a>
                )}
                <Button variant="ghost" size="icon" onClick={() => handleEdit(event)} className="text-white/50 hover:text-white">
                  <Pencil className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => deleteMutation.mutate(event.id)} className="text-red-400 hover:text-red-300">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}

        {events.length === 0 && (
          <div className="text-center py-12">
            <Calendar className="w-16 h-16 text-white/20 mx-auto mb-4" />
            <p className="text-white/50">No hay eventos. Crea el primero.</p>
          </div>
        )}
      </div>
    </div>
  );
}
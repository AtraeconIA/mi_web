import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Instagram, Youtube, Music2, Facebook, Twitter, Save, Plus, Trash2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

const platformConfig = {
  instagram: { icon: Instagram, label: 'Instagram', color: 'from-pink-500 to-purple-500', placeholder: 'https://instagram.com/...' },
  youtube: { icon: Youtube, label: 'YouTube', color: 'from-red-500 to-red-600', placeholder: 'https://youtube.com/@...' },
  spotify: { icon: Music2, label: 'Spotify', color: 'from-green-500 to-green-600', placeholder: 'https://open.spotify.com/artist/...' },
  facebook: { icon: Facebook, label: 'Facebook', color: 'from-blue-500 to-blue-600', placeholder: 'https://facebook.com/...' },
  tiktok: { icon: Music2, label: 'TikTok', color: 'from-black to-gray-800', placeholder: 'https://tiktok.com/@...' },
  twitter: { icon: Twitter, label: 'Twitter / X', color: 'from-gray-700 to-black', placeholder: 'https://x.com/...' },
};

export default function AdminSocial() {
  const [isCreating, setIsCreating] = useState(false);
  const [formData, setFormData] = useState({ platform: 'instagram', url: '', is_active: true });
  const queryClient = useQueryClient();

  const { data: socialLinks = [] } = useQuery({
    queryKey: ['socialLinks'],
    queryFn: () => base44.entities.SocialLink.list('order'),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.SocialLink.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['socialLinks'] });
      resetForm();
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SocialLink.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['socialLinks'] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.SocialLink.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['socialLinks'] }),
  });

  const resetForm = () => {
    setFormData({ platform: 'instagram', url: '', is_active: true });
    setIsCreating(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    createMutation.mutate({ ...formData, order: socialLinks.length });
  };

  const handleUrlChange = (id, url) => {
    updateMutation.mutate({ id, data: { url } });
  };

  const handleToggleActive = (id, is_active) => {
    updateMutation.mutate({ id, data: { is_active } });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-heading text-white mb-2">Redes Sociales</h2>
          <p className="text-white/60">Configura los enlaces a tus perfiles de redes sociales</p>
        </div>
        <Button
          onClick={() => setIsCreating(true)}
          className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-bold"
        >
          <Plus className="w-4 h-4 mr-2" />
          Añadir Red Social
        </Button>
      </div>

      {/* Add Form */}
      {isCreating && (
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="bg-white/5 border-white/10">
            <CardHeader>
              <CardTitle className="text-white flex items-center justify-between">
                Nueva Red Social
                <Button variant="ghost" size="icon" onClick={resetForm}>
                  <X className="w-4 h-4" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="flex gap-4 items-end">
                <div className="w-48">
                  <label className="text-white/60 text-sm mb-1 block">Plataforma</label>
                  <Select value={formData.platform} onValueChange={(v) => setFormData({ ...formData, platform: v })}>
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(platformConfig).map(([key, config]) => (
                        <SelectItem key={key} value={key}>
                          <span className="flex items-center gap-2">
                            <config.icon className="w-4 h-4" />
                            {config.label}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex-1">
                  <label className="text-white/60 text-sm mb-1 block">URL del perfil</label>
                  <Input
                    value={formData.url}
                    onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                    placeholder={platformConfig[formData.platform]?.placeholder}
                    className="bg-white/5 border-white/10 text-white"
                    required
                  />
                </div>
                <Button type="submit" className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-bold">
                  <Save className="w-4 h-4 mr-2" />
                  Guardar
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Social Links List */}
      <div className="grid gap-4">
        {socialLinks.map((link) => {
          const config = platformConfig[link.platform] || platformConfig.instagram;
          const Icon = config.icon;
          
          return (
            <motion.div
              key={link.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <Card className={`bg-white/5 border-white/10 ${!link.is_active ? 'opacity-50' : ''}`}>
                <CardContent className="p-4 flex items-center gap-4">
                  <div className={`p-3 rounded-xl bg-gradient-to-r ${config.color}`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <p className="text-white font-semibold">{config.label}</p>
                    <Input
                      value={link.url}
                      onChange={(e) => handleUrlChange(link.id, e.target.value)}
                      className="bg-white/5 border-white/10 text-white/70 text-sm mt-1"
                    />
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={link.is_active}
                        onCheckedChange={(checked) => handleToggleActive(link.id, checked)}
                      />
                      <span className="text-white/50 text-sm">{link.is_active ? 'Activo' : 'Inactivo'}</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteMutation.mutate(link.id)}
                      className="text-red-400 hover:bg-red-500/20"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}

        {socialLinks.length === 0 && !isCreating && (
          <Card className="bg-white/5 border-white/10">
            <CardContent className="py-12 text-center">
              <Instagram className="w-16 h-16 text-white/20 mx-auto mb-4" />
              <p className="text-white/50">No hay redes sociales configuradas</p>
              <Button
                onClick={() => setIsCreating(true)}
                variant="outline"
                className="mt-4 border-white/20 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Añadir la primera
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
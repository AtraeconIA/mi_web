import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, Save, Image, Type, Globe, Upload, Palette, Music, ShoppingBag, Images, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

const sections = [
  { id: 'hero', label: 'Hero / Inicio', icon: Image },
  { id: 'music', label: 'Música', icon: Music },
  { id: 'about', label: 'Sobre Mí', icon: Type },
  { id: 'shop', label: 'Tienda', icon: ShoppingBag },
  { id: 'gallery', label: 'Galería', icon: Images },
  { id: 'contact', label: 'Contacto', icon: Globe },
];

export default function AdminContent() {
  const [activeSection, setActiveSection] = useState('hero');
  const [editedContent, setEditedContent] = useState({});
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState({});
  const [newBgSection, setNewBgSection] = useState(null);
  const [newBgUrl, setNewBgUrl] = useState('');
  const queryClient = useQueryClient();

  const { data: content = [] } = useQuery({
    queryKey: ['siteContent'],
    queryFn: () => base44.entities.SiteContent.list('order'),
    refetchInterval: 2000, // Auto-refresh every 2 seconds
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SiteContent.update(id, data),
    onSuccess: () => {
      // Invalidate all related queries for instant update
      queryClient.invalidateQueries({ queryKey: ['siteContent'] });
      queryClient.invalidateQueries({ queryKey: ['heroContent'] });
      queryClient.invalidateQueries({ queryKey: ['heroBackground'] });
      queryClient.invalidateQueries({ queryKey: ['aboutBackground'] });
      queryClient.invalidateQueries({ queryKey: ['musicBackground'] });
      queryClient.invalidateQueries({ queryKey: ['galleryBackground'] });
      queryClient.invalidateQueries({ queryKey: ['shopBackground'] });
      queryClient.invalidateQueries({ queryKey: ['contactBackground'] });
    },
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.SiteContent.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['siteContent'] });
      queryClient.invalidateQueries({ queryKey: ['heroContent'] });
      queryClient.invalidateQueries({ queryKey: ['heroBackground'] });
      queryClient.invalidateQueries({ queryKey: ['aboutBackground'] });
      queryClient.invalidateQueries({ queryKey: ['musicBackground'] });
      queryClient.invalidateQueries({ queryKey: ['galleryBackground'] });
      queryClient.invalidateQueries({ queryKey: ['shopBackground'] });
      queryClient.invalidateQueries({ queryKey: ['contactBackground'] });
      setNewBgSection(null);
      setNewBgUrl('');
    },
  });

  const getSectionContent = (section) => {
    return content.filter(c => c.section === section);
  };

  const getSectionBackground = (section) => {
    return content.find(c => c.section === section && c.key === 'background_image');
  };

  const handleContentChange = (id, field, value) => {
    setEditedContent(prev => ({
      ...prev,
      [id]: { ...prev[id], [field]: value }
    }));
  };

  const handleSave = async (item) => {
    setSaving(true);
    const updates = editedContent[item.id];
    if (updates) {
      await updateMutation.mutateAsync({ id: item.id, data: updates });
    }
    setSaving(false);
  };

  const handleSaveAll = async () => {
    setSaving(true);
    for (const [id, data] of Object.entries(editedContent)) {
      await updateMutation.mutateAsync({ id, data });
    }
    setEditedContent({});
    setSaving(false);
  };

  const getContentValue = (item, field) => {
    return editedContent[item.id]?.[field] ?? item[field];
  };

  const handleFileUpload = async (e, item, field) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(prev => ({ ...prev, [item.id]: true }));
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    
    // Update local state
    handleContentChange(item.id, field, file_url);
    
    // Immediately save to database
    await updateMutation.mutateAsync({ id: item.id, data: { [field]: file_url } });
    
    setUploading(prev => ({ ...prev, [item.id]: false }));
  };

  const handleNewBgUpload = async (e, section) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(prev => ({ ...prev, [`new_${section}`]: true }));
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    
    // Immediately create the background in database
    await createMutation.mutateAsync({
      section: section,
      key: 'background_image',
      content_es: file_url,
      content_type: 'image',
      order: 0,
    });
    
    setUploading(prev => ({ ...prev, [`new_${section}`]: false }));
  };

  const handleCreateBackground = async (section) => {
    if (!newBgUrl) return;
    await createMutation.mutateAsync({
      section: section,
      key: 'background_image',
      content_es: newBgUrl,
      content_type: 'image',
      order: 0,
    });
  };

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.SiteContent.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['siteContent'] });
      queryClient.invalidateQueries({ queryKey: ['heroBackground'] });
      queryClient.invalidateQueries({ queryKey: ['aboutBackground'] });
      queryClient.invalidateQueries({ queryKey: ['musicBackground'] });
      queryClient.invalidateQueries({ queryKey: ['galleryBackground'] });
      queryClient.invalidateQueries({ queryKey: ['shopBackground'] });
      queryClient.invalidateQueries({ queryKey: ['contactBackground'] });
    },
  });

  const handleDeleteBackground = async (id) => {
    if (window.confirm('¿Eliminar la imagen de fondo? La sección volverá a tener fondo negro.')) {
      await deleteMutation.mutateAsync(id);
    }
  };

  const sectionBg = getSectionBackground(activeSection);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-heading text-white mb-2">Contenido Web</h2>
          <p className="text-white/60">Edita los textos, imágenes y fondos de tu página</p>
        </div>
        {Object.keys(editedContent).length > 0 && (
          <Button
            onClick={handleSaveAll}
            disabled={saving}
            className="bg-[#8B1538] hover:bg-[#6A1029] text-white font-bold"
          >
            <Save className="w-4 h-4 mr-2" />
            {saving ? 'Guardando...' : 'Guardar Todo'}
          </Button>
        )}
      </div>

      {/* Section Tabs */}
      <div className="flex gap-2 flex-wrap">
        {sections.map((section) => (
          <button
            key={section.id}
            onClick={() => setActiveSection(section.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
              activeSection === section.id
                ? 'bg-[#8B1538] text-white font-bold'
                : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10'
            }`}
          >
            <section.icon className="w-4 h-4" />
            {section.label}
          </button>
        ))}
      </div>

      {/* Section Background Editor */}
      <Card className="bg-white/5 border-white/10">
        <CardHeader className="pb-2">
          <CardTitle className="text-white text-lg flex items-center gap-2">
            <Image className="w-5 h-5 text-[#8B1538]" />
            Fondo de Sección
            <span className="text-xs text-white/40 font-normal ml-2">
              (aparecerá con baja opacidad detrás del contenido)
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {sectionBg ? (
            <div className="space-y-4">
              <div className="flex gap-2">
                <Input
                  value={getContentValue(sectionBg, 'content_es')}
                  onChange={(e) => handleContentChange(sectionBg.id, 'content_es', e.target.value)}
                  placeholder="https://..."
                  className="bg-white/5 border-white/10 text-white flex-1"
                />
                <label className="cursor-pointer">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleFileUpload(e, sectionBg, 'content_es')}
                    className="hidden"
                  />
                  <div className="flex items-center gap-2 px-4 py-2 bg-[#8B1538]/20 border border-[#8B1538]/30 rounded-md hover:bg-[#8B1538]/30 transition-colors text-[#8B1538] h-10">
                    <Upload className="w-4 h-4" />
                    {uploading[sectionBg.id] ? 'Subiendo...' : 'Subir'}
                  </div>
                </label>
              </div>
              {getContentValue(sectionBg, 'content_es') && (
                <div className="flex items-center gap-4">
                  <img 
                    src={getContentValue(sectionBg, 'content_es')} 
                    alt="Background preview"
                    className="h-24 w-auto rounded-lg object-cover opacity-50"
                  />
                  <p className="text-white/40 text-sm">Vista previa (se mostrará con opacidad reducida)</p>
                </div>
              )}
              <div className="flex gap-2">
                {editedContent[sectionBg.id] && (
                  <Button
                    size="sm"
                    onClick={() => handleSave(sectionBg)}
                    disabled={saving}
                    className="bg-green-500 hover:bg-green-600 text-white"
                  >
                    <Save className="w-3 h-3 mr-1" />
                    Guardar Fondo
                  </Button>
                )}
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleDeleteBackground(sectionBg.id)}
                  className="border-red-500/30 text-red-400 hover:bg-red-500/10 hover:text-red-300"
                >
                  <Trash2 className="w-3 h-3 mr-1" />
                  Eliminar Fondo
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-white/50 text-sm">No hay imagen de fondo configurada para esta sección</p>
              <div className="flex gap-2">
                <Input
                  value={newBgUrl}
                  onChange={(e) => setNewBgUrl(e.target.value)}
                  placeholder="URL de la imagen de fondo..."
                  className="bg-white/5 border-white/10 text-white flex-1"
                />
                <label className="cursor-pointer">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleNewBgUpload(e, activeSection)}
                    className="hidden"
                  />
                  <div className="flex items-center gap-2 px-4 py-2 bg-[#8B1538]/20 border border-[#8B1538]/30 rounded-md hover:bg-[#8B1538]/30 transition-colors text-[#8B1538] h-10">
                    <Upload className="w-4 h-4" />
                    {uploading[`new_${activeSection}`] ? 'Subiendo...' : 'Subir'}
                  </div>
                </label>
                <Button
                  onClick={() => handleCreateBackground(activeSection)}
                  disabled={!newBgUrl}
                  className="bg-[#8B1538] hover:bg-[#6A1029]"
                >
                  Añadir Fondo
                </Button>
              </div>
              {newBgUrl && (
                <img src={newBgUrl} alt="Preview" className="h-24 w-auto rounded-lg object-cover opacity-50" />
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Content Editor */}
      <div className="space-y-4">
        {getSectionContent(activeSection).filter(item => item.key !== 'background_image').length > 0 ? (
          getSectionContent(activeSection).filter(item => item.key !== 'background_image').map((item) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Card className="bg-white/5 border-white/10">
                <CardHeader className="pb-2">
                  <CardTitle className="text-white text-lg flex items-center justify-between">
                    <span className="capitalize">{item.key.replace(/_/g, ' ')}</span>
                    <span className="text-xs text-white/40 font-normal">
                      {item.content_type === 'image' ? '📷 Imagen' : '📝 Texto'}
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {item.content_type === 'image' ? (
                    <div className="space-y-4">
                      <div>
                        <label className="text-white/60 text-sm mb-2 block">URL o subir archivo</label>
                        <div className="flex gap-2">
                          <Input
                            value={getContentValue(item, 'content_es')}
                            onChange={(e) => handleContentChange(item.id, 'content_es', e.target.value)}
                            placeholder="https://..."
                            className="bg-white/5 border-white/10 text-white flex-1"
                          />
                          <label className="cursor-pointer">
                            <input
                              type="file"
                              accept="image/*,video/*"
                              onChange={(e) => handleFileUpload(e, item, 'content_es')}
                              className="hidden"
                            />
                            <div className="flex items-center gap-2 px-4 py-2 bg-[#8B1538]/20 border border-[#8B1538]/30 rounded-md hover:bg-[#8B1538]/30 transition-colors text-[#8B1538] h-10">
                              <Upload className="w-4 h-4" />
                              {uploading[item.id] ? 'Subiendo...' : 'Subir'}
                            </div>
                          </label>
                        </div>
                      </div>
                      {getContentValue(item, 'content_es') && (
                        <div className="mt-2 flex items-end gap-4">
                          {getContentValue(item, 'content_es').includes('.mp4') || getContentValue(item, 'content_es').includes('.webm') ? (
                            <video 
                              src={getContentValue(item, 'content_es')} 
                              className={`h-40 w-auto rounded-lg object-cover ${getContentValue(item, 'is_grayscale') ? 'grayscale' : ''}`}
                              controls
                            />
                          ) : (
                            <img 
                              src={getContentValue(item, 'content_es')} 
                              alt={item.key}
                              className={`h-40 w-auto rounded-lg object-cover ${getContentValue(item, 'is_grayscale') ? 'grayscale' : ''}`}
                            />
                          )}
                          <div className="flex items-center gap-2 bg-white/5 px-3 py-2 rounded-lg">
                            <Palette className="w-4 h-4 text-white/60" />
                            <span className="text-white/60 text-sm">Blanco y negro</span>
                            <Switch
                              checked={getContentValue(item, 'is_grayscale') || false}
                              onCheckedChange={(checked) => handleContentChange(item.id, 'is_grayscale', checked)}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div>
                      <label className="text-white/60 text-sm mb-1 block">Contenido</label>
                      {item.key.includes('description') ? (
                        <Textarea
                          value={getContentValue(item, 'content_es')}
                          onChange={(e) => handleContentChange(item.id, 'content_es', e.target.value)}
                          className="bg-white/5 border-white/10 text-white min-h-[100px]"
                          placeholder="Escribe el contenido..."
                        />
                      ) : (
                        <Input
                          value={getContentValue(item, 'content_es')}
                          onChange={(e) => handleContentChange(item.id, 'content_es', e.target.value)}
                          className="bg-white/5 border-white/10 text-white"
                          placeholder="Escribe el contenido..."
                        />
                      )}
                    </div>
                  )}

                  {editedContent[item.id] && (
                    <div className="flex justify-end">
                      <Button
                        size="sm"
                        onClick={() => handleSave(item)}
                        disabled={saving}
                        className="bg-green-500 hover:bg-green-600 text-white"
                      >
                        <Save className="w-3 h-3 mr-1" />
                        Guardar
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))
        ) : (
          <Card className="bg-white/5 border-white/10">
            <CardContent className="py-8 text-center">
              <FileText className="w-12 h-12 text-white/20 mx-auto mb-3" />
              <p className="text-white/50">No hay contenido adicional para esta sección</p>
              <p className="text-white/30 text-sm mt-1">Puedes configurar la imagen de fondo arriba</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Image, Plus, Pencil, Trash2, Save, X, Upload, GripVertical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

const categories = [
  { value: 'concert', label: 'Conciertos' },
  { value: 'photoshoot', label: 'Sesiones Fotográficas' },
  { value: 'backstage', label: 'Backstage' },
  { value: 'videoclip', label: 'Videoclips' },
];

export default function AdminGallery() {
  const [isCreating, setIsCreating] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [formData, setFormData] = useState({
    url: '',
    caption: '',
    category: 'concert',
    type: 'image',
  });
  const [uploading, setUploading] = useState(false);

  const queryClient = useQueryClient();

  const { data: gallery = [] } = useQuery({
    queryKey: ['gallery'],
    queryFn: () => base44.entities.GalleryItem.list('order'),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.GalleryItem.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['gallery'] });
      resetForm();
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.GalleryItem.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['gallery'] });
      resetForm();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.GalleryItem.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['gallery'] }),
  });

  const resetForm = () => {
    setFormData({ url: '', caption: '', category: 'concert', type: 'image' });
    setEditingItem(null);
    setIsCreating(false);
  };

  const handleEdit = (item) => {
    setFormData({
      url: item.url,
      caption: item.caption || '',
      category: item.category || 'concert',
      type: item.type || 'image',
    });
    setEditingItem(item);
    setIsCreating(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data: formData });
    } else {
      createMutation.mutate({ ...formData, order: gallery.length });
    }
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setFormData({ ...formData, url: file_url });
    setUploading(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-heading text-white mb-2">Galería</h2>
          <p className="text-white/60">Gestiona las fotos y videos de tu galería</p>
        </div>
        <Button
          onClick={() => { setIsCreating(true); setEditingItem(null); }}
          className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-bold"
        >
          <Plus className="w-4 h-4 mr-2" />
          Añadir Imagen
        </Button>
      </div>

      {/* Form */}
      {(isCreating || editingItem) && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="bg-white/5 border-white/10">
            <CardHeader>
              <CardTitle className="text-white flex items-center justify-between">
                {editingItem ? 'Editar Imagen' : 'Nueva Imagen'}
                <Button variant="ghost" size="icon" onClick={resetForm}>
                  <X className="w-4 h-4" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-white/60 text-sm">URL de imagen o subir archivo</label>
                    <Input
                      placeholder="https://..."
                      value={formData.url}
                      onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                      className="bg-white/5 border-white/10 text-white"
                    />
                    <div className="flex items-center gap-2">
                      <label className="flex-1">
                        <input
                          type="file"
                          accept="image/*,video/*"
                          onChange={handleFileUpload}
                          className="hidden"
                        />
                        <div className="flex items-center justify-center gap-2 px-4 py-2 bg-white/10 rounded-lg cursor-pointer hover:bg-white/20 transition-colors text-white/60 text-sm">
                          <Upload className="w-4 h-4" />
                          {uploading ? 'Subiendo...' : 'Subir archivo'}
                        </div>
                      </label>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-white/60 text-sm">Categoría</label>
                    <Select value={formData.category} onValueChange={(v) => setFormData({ ...formData, category: v })}>
                      <SelectTrigger className="bg-white/5 border-white/10 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Input
                  placeholder="Descripción (opcional)"
                  value={formData.caption}
                  onChange={(e) => setFormData({ ...formData, caption: e.target.value })}
                  className="bg-white/5 border-white/10 text-white"
                />

                {formData.url && (
                  <div className="mt-2">
                    <img src={formData.url} alt="Preview" className="h-40 w-auto rounded-lg object-cover" />
                  </div>
                )}

                <div className="flex justify-end gap-3">
                  <Button type="button" variant="outline" onClick={resetForm} className="border-white/20 text-white">
                    Cancelar
                  </Button>
                  <Button type="submit" className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-bold">
                    <Save className="w-4 h-4 mr-2" />
                    {editingItem ? 'Guardar' : 'Añadir'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Gallery Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {gallery.map((item) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="group relative"
          >
            <div className="aspect-square rounded-xl overflow-hidden bg-white/5">
              <img
                src={item.url}
                alt={item.caption || 'Gallery item'}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity rounded-xl flex items-center justify-center gap-2">
              <Button size="icon" variant="ghost" onClick={() => handleEdit(item)} className="text-white hover:bg-white/20">
                <Pencil className="w-4 h-4" />
              </Button>
              <Button size="icon" variant="ghost" onClick={() => deleteMutation.mutate(item.id)} className="text-red-400 hover:bg-red-500/20">
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-white/50 text-xs mt-2 truncate">{item.caption || categories.find(c => c.value === item.category)?.label}</p>
          </motion.div>
        ))}

        {gallery.length === 0 && (
          <div className="col-span-full text-center py-12">
            <Image className="w-16 h-16 text-white/20 mx-auto mb-4" />
            <p className="text-white/50">No hay imágenes en la galería</p>
          </div>
        )}
      </div>
    </div>
  );
}
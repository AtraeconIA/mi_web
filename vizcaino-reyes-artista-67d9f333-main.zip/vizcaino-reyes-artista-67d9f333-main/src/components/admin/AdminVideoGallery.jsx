import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, Save, Image, Video, Upload } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function AdminVideoGallery() {
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    thumbnail_url: '',
    video_url: '',
    instagram_url: '',
    type: 'image',
    order: 0,
    is_active: true,
  });

  const { data: items = [] } = useQuery({
    queryKey: ['adminGalleryItems'],
    queryFn: () => base44.entities.VideoGallery.list('order'),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.VideoGallery.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adminGalleryItems'] });
      resetForm();
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.VideoGallery.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adminGalleryItems'] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.VideoGallery.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['adminGalleryItems'] }),
  });

  const resetForm = () => {
    setFormData({ title: '', thumbnail_url: '', video_url: '', instagram_url: '', type: 'image', order: 0, is_active: true });
    setShowForm(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  const handleFileUpload = async (e, field) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setFormData({ ...formData, [field]: file_url });
    setUploading(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-heading text-white">Galería</h2>
          <p className="text-white/50 text-sm">Fotos y videos de Instagram para mostrar en la web</p>
        </div>
        <Button
          onClick={() => setShowForm(!showForm)}
          className="bg-[#8B1538] hover:bg-[#6A1029]"
        >
          <Plus className="w-4 h-4 mr-2" />
          Añadir Contenido
        </Button>
      </div>

      {/* Add Form */}
      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white/5 rounded-xl p-6 space-y-4 border border-white/10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-white/60 text-sm mb-2 block">Título</label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Nombre del contenido"
                className="bg-white/5 border-white/10 text-white"
                required
              />
            </div>
            <div>
              <label className="text-white/60 text-sm mb-2 block">Tipo</label>
              <Select value={formData.type} onValueChange={(v) => setFormData({ ...formData, type: v })}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="image">Foto</SelectItem>
                  <SelectItem value="video">Video</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-white/60 text-sm mb-2 block">Orden</label>
              <Input
                type="number"
                value={formData.order}
                onChange={(e) => setFormData({ ...formData, order: parseInt(e.target.value) })}
                className="bg-white/5 border-white/10 text-white"
              />
            </div>
          </div>

          {/* Thumbnail */}
          <div>
            <label className="text-white/60 text-sm mb-2 block">Imagen/Miniatura (formato vertical tipo Instagram)</label>
            <div className="flex gap-2">
              <Input
                value={formData.thumbnail_url}
                onChange={(e) => setFormData({ ...formData, thumbnail_url: e.target.value })}
                placeholder="https://... o sube una imagen"
                className="bg-white/5 border-white/10 text-white flex-1"
                required
              />
              <label className="cursor-pointer">
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleFileUpload(e, 'thumbnail_url')}
                  className="hidden"
                />
                <div className="flex items-center gap-2 px-4 py-2 bg-[#8B1538]/20 border border-[#8B1538]/30 rounded-md hover:bg-[#8B1538]/30 transition-colors text-[#8B1538] h-10">
                  <Upload className="w-4 h-4" />
                  {uploading ? 'Subiendo...' : 'Subir'}
                </div>
              </label>
            </div>
          </div>

          {/* Video URL (only if type is video) */}
          {formData.type === 'video' && (
            <div className="space-y-4">
              <div>
                <label className="text-white/60 text-sm mb-2 block">URL del Video (archivo mp4 o URL directa)</label>
                <div className="flex gap-2">
                  <Input
                    value={formData.video_url}
                    onChange={(e) => setFormData({ ...formData, video_url: e.target.value })}
                    placeholder="https://... url del video"
                    className="bg-white/5 border-white/10 text-white flex-1"
                  />
                  <label className="cursor-pointer">
                    <input
                      type="file"
                      accept="video/*"
                      onChange={(e) => handleFileUpload(e, 'video_url')}
                      className="hidden"
                    />
                    <div className="flex items-center gap-2 px-4 py-2 bg-[#8B1538]/20 border border-[#8B1538]/30 rounded-md hover:bg-[#8B1538]/30 transition-colors text-[#8B1538] h-10">
                      <Upload className="w-4 h-4" />
                      Subir
                    </div>
                  </label>
                </div>
              </div>
              <div>
                <label className="text-white/60 text-sm mb-2 block">O enlace de Instagram Reel (opcional)</label>
                <Input
                  value={formData.instagram_url}
                  onChange={(e) => setFormData({ ...formData, instagram_url: e.target.value })}
                  placeholder="https://www.instagram.com/reel/..."
                  className="bg-white/5 border-white/10 text-white"
                />
                <p className="text-white/30 text-xs mt-1">Si pones un enlace de Instagram, se abrirá en una nueva pestaña</p>
              </div>
            </div>
          )}

          {/* Preview */}
          {formData.thumbnail_url && (
            <div className="flex items-center gap-4">
              <div className="w-20 aspect-[9/16] rounded-lg overflow-hidden bg-white/10">
                <img src={formData.thumbnail_url} alt="Preview" className="w-full h-full object-cover" />
              </div>
              <span className="text-white/40 text-sm">Vista previa (formato iPhone)</span>
            </div>
          )}

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={resetForm} className="border-white/20 text-white">
              Cancelar
            </Button>
            <Button type="submit" className="bg-[#8B1538] hover:bg-[#6A1029]">
              <Save className="w-4 h-4 mr-2" />
              Guardar
            </Button>
          </div>
        </form>
      )}

      {/* Items List */}
      <div className="grid gap-4">
        {items.length === 0 ? (
          <div className="text-center py-12 bg-white/5 rounded-xl border border-white/10">
            <Image className="w-12 h-12 text-white/20 mx-auto mb-4" />
            <p className="text-white/40">No hay contenido en la galería</p>
            <p className="text-white/30 text-sm mt-1">Añade fotos y videos de Instagram</p>
          </div>
        ) : (
          items.map((item) => (
            <div
              key={item.id}
              className="bg-white/5 rounded-xl p-4 border border-white/10 flex items-center gap-4"
            >
              <div className="w-12 h-20 rounded-lg overflow-hidden bg-white/10 flex-shrink-0">
                <img
                  src={item.thumbnail_url}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h4 className="text-white font-medium">{item.title}</h4>
                  {item.type === 'video' ? (
                    <span className="text-xs bg-red-500/20 text-red-400 px-2 py-0.5 rounded">Video</span>
                  ) : (
                    <span className="text-xs bg-blue-500/20 text-blue-400 px-2 py-0.5 rounded">Foto</span>
                  )}
                </div>
                <p className="text-white/40 text-sm truncate">{item.instagram_url || item.video_url || item.thumbnail_url}</p>
              </div>
              <div className="flex items-center gap-4 flex-shrink-0">
                <div className="flex items-center gap-2">
                  <span className="text-white/40 text-sm">Activo</span>
                  <Switch
                    checked={item.is_active}
                    onCheckedChange={(checked) =>
                      updateMutation.mutate({ id: item.id, data: { is_active: checked } })
                    }
                  />
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => deleteMutation.mutate(item.id)}
                  className="text-red-400 hover:text-red-300 hover:bg-red-400/10"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
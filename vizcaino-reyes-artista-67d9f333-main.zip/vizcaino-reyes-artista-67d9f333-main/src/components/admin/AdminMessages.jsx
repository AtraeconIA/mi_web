import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Trash2, Check, Eye, Phone, Calendar, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import moment from 'moment';

const subjectLabels = {
  booking: { label: 'Contratación', color: 'bg-yellow-500/20 text-yellow-400' },
  press: { label: 'Prensa', color: 'bg-blue-500/20 text-blue-400' },
  collaboration: { label: 'Colaboración', color: 'bg-purple-500/20 text-purple-400' },
  fan: { label: 'Fan', color: 'bg-pink-500/20 text-pink-400' },
  other: { label: 'Otro', color: 'bg-gray-500/20 text-gray-400' },
};

export default function AdminMessages() {
  const [selectedMessage, setSelectedMessage] = useState(null);
  const queryClient = useQueryClient();

  const { data: messages = [] } = useQuery({
    queryKey: ['messages'],
    queryFn: () => base44.entities.ContactMessage.list('-created_date'),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ContactMessage.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['messages'] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.ContactMessage.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['messages'] });
      if (selectedMessage?.id === id) setSelectedMessage(null);
    },
  });

  const handleSelectMessage = (msg) => {
    setSelectedMessage(msg);
    if (msg.status === 'pending') {
      updateMutation.mutate({ id: msg.id, data: { status: 'read' } });
    }
  };

  const handleMarkReplied = (id) => {
    updateMutation.mutate({ id, data: { status: 'replied' } });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-heading text-white mb-2">Mensajes</h2>
        <p className="text-white/60">Gestiona los mensajes de contacto recibidos</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Messages List */}
        <div className="lg:col-span-1 space-y-2 max-h-[600px] overflow-y-auto pr-2">
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <Card 
                className={`bg-white/5 border-white/10 cursor-pointer transition-all hover:bg-white/10 ${
                  selectedMessage?.id === msg.id ? 'ring-2 ring-yellow-400/50' : ''
                } ${msg.status === 'pending' ? 'border-l-4 border-l-yellow-400' : ''}`}
                onClick={() => handleSelectMessage(msg)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <p className="text-white font-medium">{msg.name}</p>
                      <p className="text-white/40 text-xs">{msg.email}</p>
                    </div>
                    <span className={`px-2 py-0.5 rounded-full text-xs ${subjectLabels[msg.subject]?.color || subjectLabels.other.color}`}>
                      {subjectLabels[msg.subject]?.label || 'Otro'}
                    </span>
                  </div>
                  <p className="text-white/60 text-sm line-clamp-2">{msg.message}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-white/30 text-xs">
                      {moment(msg.created_date).fromNow()}
                    </span>
                    <span className={`w-2 h-2 rounded-full ${
                      msg.status === 'pending' ? 'bg-yellow-400' :
                      msg.status === 'read' ? 'bg-blue-400' : 'bg-green-400'
                    }`} />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}

          {messages.length === 0 && (
            <div className="text-center py-12">
              <Mail className="w-16 h-16 text-white/20 mx-auto mb-4" />
              <p className="text-white/50">No hay mensajes</p>
            </div>
          )}
        </div>

        {/* Message Detail */}
        <div className="lg:col-span-2">
          {selectedMessage ? (
            <Card className="bg-white/5 border-white/10 h-full">
              <CardHeader className="border-b border-white/10">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-white text-xl">{selectedMessage.name}</CardTitle>
                    <div className="flex items-center gap-4 mt-2 text-white/50 text-sm">
                      <a href={`mailto:${selectedMessage.email}`} className="flex items-center gap-1 hover:text-yellow-400">
                        <Mail className="w-4 h-4" />
                        {selectedMessage.email}
                      </a>
                      {selectedMessage.phone && (
                        <a href={`tel:${selectedMessage.phone}`} className="flex items-center gap-1 hover:text-yellow-400">
                          <Phone className="w-4 h-4" />
                          {selectedMessage.phone}
                        </a>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${subjectLabels[selectedMessage.subject]?.color || subjectLabels.other.color}`}>
                      <Tag className="w-3 h-3 inline mr-1" />
                      {subjectLabels[selectedMessage.subject]?.label || 'Otro'}
                    </span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="flex items-center gap-2 text-white/40 text-sm mb-4">
                  <Calendar className="w-4 h-4" />
                  {moment(selectedMessage.created_date).format('DD MMM YYYY, HH:mm')}
                </div>
                
                <div className="bg-black/30 rounded-xl p-6 mb-6">
                  <p className="text-white/90 whitespace-pre-wrap leading-relaxed">
                    {selectedMessage.message}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <Button
                    asChild
                    className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-bold"
                  >
                    <a href={`mailto:${selectedMessage.email}?subject=Re: Contacto desde web`}>
                      <Mail className="w-4 h-4 mr-2" />
                      Responder
                    </a>
                  </Button>
                  {selectedMessage.status !== 'replied' && (
                    <Button
                      variant="outline"
                      onClick={() => handleMarkReplied(selectedMessage.id)}
                      className="border-green-500/50 text-green-400 hover:bg-green-500/20"
                    >
                      <Check className="w-4 h-4 mr-2" />
                      Marcar como respondido
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    onClick={() => deleteMutation.mutate(selectedMessage.id)}
                    className="text-red-400 hover:bg-red-500/20 ml-auto"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Eliminar
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="bg-white/5 border-white/10 h-full flex items-center justify-center">
              <CardContent className="text-center py-12">
                <Eye className="w-16 h-16 text-white/20 mx-auto mb-4" />
                <p className="text-white/50">Selecciona un mensaje para verlo</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
import Home from './pages/Home';
import Admin from './pages/Admin';
import PrivacyPolicy from './pages/PrivacyPolicy';
import LegalNotice from './pages/LegalNotice';
import CookiesPolicy from './pages/CookiesPolicy';
import TermsOfUse from './pages/TermsOfUse';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Home": Home,
    "Admin": Admin,
    "PrivacyPolicy": PrivacyPolicy,
    "LegalNotice": LegalNotice,
    "CookiesPolicy": CookiesPolicy,
    "TermsOfUse": TermsOfUse,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};
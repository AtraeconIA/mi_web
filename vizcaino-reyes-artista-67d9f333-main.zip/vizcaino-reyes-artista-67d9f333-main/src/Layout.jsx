import React from 'react';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';

export default function Layout({ children, currentPageName }) {
  const isAdminPage = currentPageName === 'Admin';

  if (isAdminPage) {
    return (
      <div className="min-h-screen bg-black text-white">
        {children}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      <main>
        {children}
      </main>
      <div className="relative z-20 bg-black">
        <Footer />
      </div>
    </div>
  );
}
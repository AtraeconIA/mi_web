import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  LayoutDashboard, Calendar, Music, Image, FileText, 
  Users, Mail, Settings, ChevronRight, Plus, Pencil, 
  Trash2, Save, X, Upload, Eye, BarChart3, TrendingUp,
  MessageSquare, ExternalLink, Disc
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

import AdminEvents from '../components/admin/AdminEvents';
import AdminContent from '../components/admin/AdminContent';
import AdminGallery from '../components/admin/AdminGallery';
import AdminMessages from '../components/admin/AdminMessages';
import AdminSocial from '../components/admin/AdminSocial';
import AdminVideoGallery from '../components/admin/AdminVideoGallery';

export default function Admin() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const queryClient = useQueryClient();

  const { data: videos = [] } = useQuery({
    queryKey: ['videos'],
    queryFn: () => base44.entities.VideoGallery.list('order'),
  });

  const { data: messages = [] } = useQuery({
    queryKey: ['messages'],
    queryFn: () => base44.entities.ContactMessage.list('-created_date'),
  });

  const { data: gallery = [] } = useQuery({
    queryKey: ['gallery'],
    queryFn: () => base44.entities.GalleryItem.list('order'),
  });

  const stats = [
    { label: 'Videos Galería', value: videos.length, icon: Music, color: 'from-[#8B1538] to-[#B91C4A]' },
    { label: 'Mensajes Nuevos', value: messages.filter(m => m.status === 'pending').length, icon: Mail, color: 'from-[#8B1538]/80 to-[#6A1029]' },
    { label: 'Fotos en Galería', value: gallery.length, icon: Image, color: 'from-[#1E3A5F] to-[#2E5A8F]' },
    { label: 'Total Mensajes', value: messages.length, icon: MessageSquare, color: 'from-white/20 to-white/10' },
  ];

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'content', label: 'Contenido Web', icon: FileText },
    { id: 'videos', label: 'Videos Galería', icon: Music },
    { id: 'gallery', label: 'Galería Fotos', icon: Image },
    { id: 'messages', label: 'Mensajes', icon: Mail },
  ];

  // Analytics for last 30 days
  const { data: analyticsData = { pageVisits: 0, shopClicks: 0, formStarts: 0, formSubmits: 0, totalInteractions: 0 } } = useQuery({
    queryKey: ['analytics'],
    queryFn: async () => {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      
      const allEvents = await base44.entities.Analytics.list('-created_date', 1000);
      const recentEvents = allEvents.filter(e => new Date(e.created_date) > thirtyDaysAgo);
      
      return {
        pageVisits: recentEvents.filter(e => e.event_type === 'page_visit').length,
        shopClicks: recentEvents.filter(e => e.event_type === 'shop_click').length,
        formStarts: recentEvents.filter(e => e.event_type === 'contact_form_start').length,
        formSubmits: recentEvents.filter(e => e.event_type === 'contact_form_submit').length,
        totalInteractions: recentEvents.filter(e => 
          e.event_type === 'shop_click' || 
          e.event_type === 'contact_form_start' || 
          e.event_type === 'contact_form_submit'
        ).length
      };
    }
  });

  return (
    <div className="min-h-screen bg-neutral-950">
      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 min-h-screen bg-black border-r border-white/10 p-6 fixed left-0 top-0">
          <div className="mb-10">
            <h1 className="font-heading text-2xl text-white">VIZCAÍNO</h1>
            <p className="text-white/40 text-sm">Panel de Administración</p>
          </div>

          <nav className="space-y-2">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                  activeTab === item.id
                    ? 'bg-gradient-to-r from-[#8B1538]/20 to-[#B91C4A]/20 text-[#B91C4A] border border-[#8B1538]/30'
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
                {activeTab === item.id && <ChevronRight className="w-4 h-4 ml-auto" />}
              </button>
            ))}
          </nav>

          <div className="absolute bottom-6 left-6 right-6">
            <a 
              href="/" 
              className="flex items-center gap-2 text-white/40 hover:text-white transition-colors text-sm"
            >
              <Eye className="w-4 h-4" />
              Ver sitio web
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 ml-64 p-8">
          {/* Dashboard */}
          {activeTab === 'dashboard' && (
            <div className="space-y-8">
              <div>
                <h2 className="text-3xl font-heading text-white mb-2">Dashboard</h2>
                <p className="text-white/60">Resumen general de tu sitio web</p>
              </div>

              {/* Analytics Stats */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <Card className="bg-gradient-to-br from-[#8B1538]/20 to-[#8B1538]/5 border-[#8B1538]/30">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 mb-3">
                        <Users className="w-6 h-6 text-[#8B1538]" />
                        <span className="text-white/70 text-sm font-medium">Visitantes</span>
                      </div>
                      <p className="text-4xl font-heading text-white mb-1">{analyticsData.pageVisits}</p>
                      <p className="text-white/40 text-xs">Últimos 30 días</p>
                    </CardContent>
                  </Card>
                </motion.div>
                
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                >
                  <Card className="bg-white/5 border-white/10">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 mb-3">
                        <TrendingUp className="w-6 h-6 text-green-500" />
                        <span className="text-white/70 text-sm font-medium">Interacciones</span>
                      </div>
                      <p className="text-4xl font-heading text-white mb-1">{analyticsData.totalInteractions}</p>
                      <p className="text-white/40 text-xs">Total acciones</p>
                    </CardContent>
                  </Card>
                </motion.div>
                
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <Card className="bg-white/5 border-white/10">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 mb-3">
                        <MessageSquare className="w-6 h-6 text-blue-500" />
                        <span className="text-white/70 text-sm font-medium">Formularios</span>
                      </div>
                      <p className="text-4xl font-heading text-white mb-1">{analyticsData.formStarts}</p>
                      <p className="text-white/40 text-xs">{analyticsData.formSubmits} enviados</p>
                    </CardContent>
                  </Card>
                </motion.div>
                
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  <Card className="bg-white/5 border-white/10">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 mb-3">
                        <Disc className="w-6 h-6 text-purple-500" />
                        <span className="text-white/70 text-sm font-medium">Clicks Disco</span>
                      </div>
                      <p className="text-4xl font-heading text-white mb-1">{analyticsData.shopClicks}</p>
                      <p className="text-white/40 text-xs">WhatsApp abiertos</p>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>

              {/* Recent Messages */}
              <Card className="bg-white/5 border-white/10">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Mail className="w-5 h-5 text-[#8B1538]" />
                    Mensajes Recientes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {messages.slice(0, 5).map((msg) => (
                    <div key={msg.id} className="flex items-center justify-between py-3 border-b border-white/5 last:border-0">
                      <div>
                        <p className="text-white font-medium">{msg.name}</p>
                        <p className="text-white/40 text-sm">{msg.email}</p>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                        msg.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                        msg.status === 'read' ? 'bg-blue-500/20 text-blue-400' :
                        'bg-green-500/20 text-green-400'
                      }`}>
                        {msg.status === 'pending' ? 'Nuevo' : msg.status === 'read' ? 'Leído' : 'Respondido'}
                      </span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          )}

          {/* Content */}
          {activeTab === 'content' && <AdminContent />}

          {/* Video Gallery */}
          {activeTab === 'videos' && <AdminVideoGallery />}

          {/* Gallery */}
          {activeTab === 'gallery' && <AdminGallery />}

          {/* Messages */}
          {activeTab === 'messages' && <AdminMessages />}
        </main>
      </div>
    </div>
  );
}
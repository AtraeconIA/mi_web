import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-black text-white py-20 md:py-28">
      <div className="container mx-auto px-4 max-w-3xl">
        <Link to={createPageUrl('Home')} className="inline-flex items-center gap-2 text-white/60 hover:text-white mb-8 transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Volver al inicio
        </Link>
        
        <h1 className="font-heading text-4xl md:text-5xl text-white mb-8">Política de Privacidad</h1>
        
        <div className="prose prose-invert prose-sm max-w-none text-white/70 space-y-6">
          <p><strong>Última actualización:</strong> {new Date().toLocaleDateString('es-ES')}</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">1. Responsable del Tratamiento</h2>
          <p>El responsable del tratamiento de los datos personales es Vizcaíno Reyes, con correo electrónico de contacto: contratacionvizcainoreyes@gmail.com</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">2. Datos Recopilados</h2>
          <p>Recopilamos los siguientes datos personales a través del formulario de contacto:</p>
          <ul className="list-disc pl-6 space-y-1">
            <li>Nombre</li>
            <li>Correo electrónico</li>
            <li>Teléfono (opcional)</li>
            <li>Mensaje</li>
          </ul>
          
          <h2 className="text-white text-xl font-semibold mt-8">3. Finalidad del Tratamiento</h2>
          <p>Los datos recopilados se utilizan para:</p>
          <ul className="list-disc pl-6 space-y-1">
            <li>Responder a consultas y solicitudes de información</li>
            <li>Gestionar contrataciones y colaboraciones</li>
            <li>Enviar información sobre eventos y novedades (previo consentimiento)</li>
          </ul>
          
          <h2 className="text-white text-xl font-semibold mt-8">4. Base Legal</h2>
          <p>El tratamiento de datos se basa en el consentimiento del interesado al enviar el formulario de contacto.</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">5. Conservación de Datos</h2>
          <p>Los datos se conservarán mientras sean necesarios para la finalidad para la que fueron recogidos y durante los plazos legalmente establecidos.</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">6. Derechos del Usuario</h2>
          <p>El usuario puede ejercer sus derechos de acceso, rectificación, supresión, portabilidad, limitación y oposición enviando un correo a contratacionvizcainoreyes@gmail.com</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">7. Seguridad</h2>
          <p>Se han adoptado las medidas técnicas y organizativas necesarias para garantizar la seguridad de los datos personales.</p>
        </div>
      </div>
    </div>
  );
}
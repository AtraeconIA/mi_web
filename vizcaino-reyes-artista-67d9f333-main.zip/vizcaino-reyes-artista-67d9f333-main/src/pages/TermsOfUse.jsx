import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function TermsOfUse() {
  return (
    <div className="min-h-screen bg-black text-white py-20 md:py-28">
      <div className="container mx-auto px-4 max-w-3xl">
        <Link to={createPageUrl('Home')} className="inline-flex items-center gap-2 text-white/60 hover:text-white mb-8 transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Volver al inicio
        </Link>
        
        <h1 className="font-heading text-4xl md:text-5xl text-white mb-8">Términos de Uso</h1>
        
        <div className="prose prose-invert prose-sm max-w-none text-white/70 space-y-6">
          <p><strong>Última actualización:</strong> {new Date().toLocaleDateString('es-ES')}</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">1. Aceptación de los Términos</h2>
          <p>Al acceder y utilizar este sitio web, aceptas estos términos de uso en su totalidad. Si no estás de acuerdo con alguno de estos términos, no debes usar este sitio.</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">2. Uso del Sitio Web</h2>
          <p>Este sitio web está destinado a proporcionar información sobre el artista Vizcaíno Reyes, su música, eventos y productos oficiales. El usuario se compromete a:</p>
          <ul className="list-disc pl-6 space-y-1">
            <li>Usar el sitio de forma lícita y respetando los derechos de terceros</li>
            <li>No realizar actividades que puedan dañar el sitio o interferir en su funcionamiento</li>
            <li>No reproducir, duplicar, copiar o explotar el contenido sin autorización</li>
          </ul>
          
          <h2 className="text-white text-xl font-semibold mt-8">3. Compra de Productos</h2>
          <p>La compra de productos (discos, merchandising) se realiza a través de WhatsApp. El precio indicado incluye IVA. Los envíos se realizan a toda España de forma gratuita.</p>
          <p>El usuario tiene derecho a desistir de la compra en un plazo de 14 días desde la recepción del producto, siempre que este se encuentre en perfecto estado.</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">4. Contenido de Terceros</h2>
          <p>Este sitio puede incluir contenido de terceros como reproductores de música (Spotify, YouTube) y enlaces a redes sociales. El uso de estos servicios está sujeto a sus propios términos y condiciones.</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">5. Limitación de Responsabilidad</h2>
          <p>El titular del sitio no será responsable de:</p>
          <ul className="list-disc pl-6 space-y-1">
            <li>Errores u omisiones en el contenido</li>
            <li>Interrupciones temporales del servicio</li>
            <li>Daños derivados del uso o imposibilidad de uso del sitio</li>
          </ul>
          
          <h2 className="text-white text-xl font-semibold mt-8">6. Modificaciones</h2>
          <p>Nos reservamos el derecho de modificar estos términos en cualquier momento. Los cambios entrarán en vigor desde su publicación en el sitio web.</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">7. Legislación Aplicable</h2>
          <p>Estos términos se rigen por la legislación española. Para cualquier controversia, las partes se someten a los tribunales de Zaragoza.</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">8. Contacto</h2>
          <p>Para cualquier consulta sobre estos términos, puedes contactarnos en: contratacionvizcainoreyes@gmail.com</p>
        </div>
      </div>
    </div>
  );
}
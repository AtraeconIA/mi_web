import React, { useEffect, useState, lazy, Suspense, memo } from 'react';
import HeroSection from '../components/sections/HeroSection';

// Lazy load sections for better performance
const MusicSection = lazy(() => import('../components/sections/MusicSection'));
const AboutSection = lazy(() => import('../components/sections/AboutSection'));
const GallerySection = lazy(() => import('../components/sections/GallerySection'));
const ShopSection = lazy(() => import('../components/sections/ShopSection'));
const ContactSection = lazy(() => import('../components/sections/ContactSection'));

// Minimal loading fallback - transparent to avoid white flash
const SectionLoader = memo(() => (
  <div className="min-h-[30vh] bg-black" />
));

export default function Home() {
  const [windowHeight, setWindowHeight] = useState(typeof window !== 'undefined' ? window.innerHeight : 800);

  useEffect(() => {
    let resizeTimeout;
    const handleResize = () => {
      // Debounce resize for better performance
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(() => setWindowHeight(window.innerHeight), 100);
    };
    window.addEventListener('resize', handleResize, { passive: true });
    return () => {
      window.removeEventListener('resize', handleResize);
      clearTimeout(resizeTimeout);
    };
  }, []);
  
  return (
    <div className="relative bg-black">
      {/* Hero Section - Fixed at top, will be covered by scrolling content */}
      <div className="fixed top-0 left-0 right-0 h-screen z-0 transform-gpu">
        <HeroSection />
      </div>
      
      {/* Spacer to allow scrolling past hero */}
      <div style={{ height: windowHeight }} className="pointer-events-none" />
      
      {/* Scrollable Content - Covers hero as you scroll with solid black background */}
      <div className="relative z-10 transform-gpu bg-black">
        {/* Transition spacer from hero to content */}
        <div className="h-16 md:h-24 bg-gradient-to-b from-transparent to-black" />
        <Suspense fallback={<SectionLoader />}>
          <MusicSection />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <AboutSection />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <GallerySection />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <ShopSection />
        </Suspense>
        <Suspense fallback={<SectionLoader />}>
          <ContactSection />
        </Suspense>
      </div>
    </div>
  );
}
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function CookiesPolicy() {
  return (
    <div className="min-h-screen bg-black text-white py-20 md:py-28">
      <div className="container mx-auto px-4 max-w-3xl">
        <Link to={createPageUrl('Home')} className="inline-flex items-center gap-2 text-white/60 hover:text-white mb-8 transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Volver al inicio
        </Link>
        
        <h1 className="font-heading text-4xl md:text-5xl text-white mb-8">Política de Cookies</h1>
        
        <div className="prose prose-invert prose-sm max-w-none text-white/70 space-y-6">
          <p><strong>Última actualización:</strong> {new Date().toLocaleDateString('es-ES')}</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">1. ¿Qué son las Cookies?</h2>
          <p>Las cookies son pequeños archivos de texto que se almacenan en tu dispositivo cuando visitas un sitio web. Se utilizan para mejorar la experiencia del usuario y recopilar información sobre el uso del sitio.</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">2. Tipos de Cookies que Utilizamos</h2>
          
          <h3 className="text-white text-lg font-medium mt-6">Cookies Técnicas</h3>
          <p>Son necesarias para el funcionamiento básico del sitio web. Permiten la navegación y el uso de las diferentes opciones del sitio.</p>
          
          <h3 className="text-white text-lg font-medium mt-6">Cookies de Análisis</h3>
          <p>Nos permiten medir y analizar la navegación de los usuarios en el sitio web para mejorar nuestros servicios.</p>
          
          <h3 className="text-white text-lg font-medium mt-6">Cookies de Terceros</h3>
          <p>Este sitio puede incluir contenido de terceros como reproductores de Spotify o YouTube, que pueden establecer sus propias cookies.</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">3. Gestión de Cookies</h2>
          <p>Puedes gestionar las cookies a través de la configuración de tu navegador. A continuación te indicamos cómo hacerlo en los navegadores más comunes:</p>
          <ul className="list-disc pl-6 space-y-1">
            <li><strong>Chrome:</strong> Configuración → Privacidad y seguridad → Cookies</li>
            <li><strong>Firefox:</strong> Opciones → Privacidad y seguridad</li>
            <li><strong>Safari:</strong> Preferencias → Privacidad</li>
            <li><strong>Edge:</strong> Configuración → Privacidad y servicios</li>
          </ul>
          
          <h2 className="text-white text-xl font-semibold mt-8">4. Actualizaciones</h2>
          <p>Esta política de cookies puede ser actualizada en cualquier momento. Te recomendamos revisarla periódicamente.</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">5. Contacto</h2>
          <p>Para cualquier consulta sobre nuestra política de cookies, puedes contactarnos en: contratacionvizcainoreyes@gmail.com</p>
        </div>
      </div>
    </div>
  );
}
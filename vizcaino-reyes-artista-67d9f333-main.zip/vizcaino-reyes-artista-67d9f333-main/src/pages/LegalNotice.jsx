import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function LegalNotice() {
  return (
    <div className="min-h-screen bg-black text-white py-20 md:py-28">
      <div className="container mx-auto px-4 max-w-3xl">
        <Link to={createPageUrl('Home')} className="inline-flex items-center gap-2 text-white/60 hover:text-white mb-8 transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Volver al inicio
        </Link>
        
        <h1 className="font-heading text-4xl md:text-5xl text-white mb-8">Aviso Legal</h1>
        
        <div className="prose prose-invert prose-sm max-w-none text-white/70 space-y-6">
          <p><strong>Última actualización:</strong> {new Date().toLocaleDateString('es-ES')}</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">1. Datos Identificativos</h2>
          <p>En cumplimiento del deber de información establecido en la Ley 34/2002 de Servicios de la Sociedad de la Información y el Comercio Electrónico (LSSI-CE), se facilitan los siguientes datos:</p>
          <ul className="list-disc pl-6 space-y-1">
            <li><strong>Titular:</strong> Vizcaíno Reyes</li>
            <li><strong>Email:</strong> contratacionvizcainoreyes@gmail.com</li>
            <li><strong>Actividad:</strong> Artista musical</li>
          </ul>
          
          <h2 className="text-white text-xl font-semibold mt-8">2. Objeto</h2>
          <p>Este sitio web tiene como finalidad la promoción del artista Vizcaíno Reyes, su música, eventos y la venta de productos oficiales.</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">3. Propiedad Intelectual</h2>
          <p>Todos los contenidos de este sitio web (textos, fotografías, gráficos, imágenes, logotipos, iconos, tecnología, software, enlaces, contenidos audiovisuales) son propiedad de Vizcaíno Reyes o de terceros que han autorizado su uso.</p>
          <p>Queda prohibida cualquier forma de reproducción, distribución, comunicación pública, transformación o cualquier otra actividad similar sin autorización previa y por escrito.</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">4. Responsabilidad</h2>
          <p>El titular no se hace responsable de los daños y perjuicios que pudieran derivarse del uso de la información de esta web ni de las decisiones que el usuario pueda tomar sobre la base de la misma.</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">5. Enlaces Externos</h2>
          <p>Este sitio web puede contener enlaces a sitios de terceros. El titular no se responsabiliza del contenido ni del estado de dichos sitios.</p>
          
          <h2 className="text-white text-xl font-semibold mt-8">6. Legislación Aplicable</h2>
          <p>El presente Aviso Legal se rige por la legislación española vigente.</p>
        </div>
      </div>
    </div>
  );
}